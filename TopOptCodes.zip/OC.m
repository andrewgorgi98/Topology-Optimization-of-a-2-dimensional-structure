
%% OPTIMALITY CRITERIA UPDATE
function [gammanew]=OC(gamma,df0,df,f_func,isUniform,Vr) 
%-----------------------------------------------------------
% df0: functional sensitivity
% df : current constraint sensitivity
% f_func: function to update constraint value
% isUniform: flag, "true" if mesh uniform
%-----------------------------------------------------------
  lower = 0; upper = 100000; maxmove = 0.1; tol = 1e-4;
  Nelem = length(df);
  while (upper-lower > tol)
    lmid = 0.5*(upper+lower);
    if isUniform
        gammanew = max( 0.001, max(gamma-maxmove,min(1.,min(gamma+maxmove,gamma.*sqrt(-df0 ./ (lmid*1/Nelem))))));
         f = sum(gammanew) - Vr*Nelem;
    else
        gammanew = max( 0.001, max(gamma-maxmove,min(1.,min(gamma+maxmove,gamma.*sqrt(-df0 ./ (lmid*df'))))));
        [f,~] = f_func(gammanew, Vr, Vr);
         f = f(1);
    end 
    if f > 0
      lower = lmid;
    else
      upper = lmid;
    end
  end
  %------------------------------------------------------------------------
end