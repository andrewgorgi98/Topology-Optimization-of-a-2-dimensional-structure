classdef Constraint
    %CONSTRAINT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        Nodes;
        fix;
    end
    
    methods
        %------------------------------------------------------------------
        function this = Constraint(Nodes, fix)
            this.Nodes = Nodes;
            this.fix   = fix;
        end
       %-------------------------------------------------------------------
    end
end

