%%% MAIN SCRIPT FOR THE SOLUTION OF A TOPOLOGY OPTIMIZATION PROBLEM
% Problem statement
%----------------------------------------------
%%% minimize work done on the system
%%% P.      min C(x) = \sum (x_e)^p * u(x_e)^T K_e u(x_e)
%%% s.t.    V(x)/V_0 <= Vr_max
%%%         V(x)/V_0 >= Vr_min;
%%%         0 < x_min < x_e <= 1
%----------------------------------------------
% Main parameters and variables
%------------------------------
% C(x)       : objective functional, work done on the system
% x          : design variable, density of material, x = [x_e], e = 1,...,Nelem
% u(x)       : displacement vector [mm]
% K          : global stiffness matrix
% K_e        : local stiffness matrix
% f          : vector of forces acting on the system
% V(x)       : material volume after optimization [mm^2]
% V_0        : domain total volume [mm^2]
% Vr_max     : maximum fraction of total volume to be occupied by material
% Vr_min     : minimal fraction of total volume to be occupied by material
% penal      : SIMP penalty coefficient (usually p = 3)
% Lx         : domain horizontal length [mm]
% Ly         : domain vertical length [mm]
%-----------------------------------------------------------
%% INITIALIZE PARAMETERS
close all; clear all;
% geometrical
%-------------
Lx  = 1000; %% mm
Ly  = 200; %% mm
V_0 = Lx*Ly;
E   = 210000;
nu  = 0.3;
t   = 60; %% mm (elements width)
Yield_S = 275; %MPa

% algorithm parameters
%---------------------
nelx   = 100; nely = 20; Nelem = nelx*nely;
Vr_min = 0.25;
Vr_max = 0.27;
rmin   = 1.5;
Vmin   = 0.001;
maxIt  = 100;
%--------------------------------------------------------------------------
%% INITIALIZE PROBLEM
%--------------------------------------------------------------------------
Problem = TopOpt(nelx, nely, Lx, Ly, V_0);
Problem = Problem.buildMesh();
isUniform = true;
%-----------------------------
%% SET PROPERTY
%-----------------------------
Problem = Problem.createProp(1, E, nu, t);
%--------------------------------------------------------------------------
%% IMPOSE BC
% constraint = [fixX,fixY , xMin,xMax, yMin,yMax]
%----------------
constraints(1,:) = [1,1, 0,0, Ly,Ly];
constraints(2,:) = [1,1, Lx,Lx, Ly,Ly];
constraints(3,:) = [1,1, 0,0, 0,2/5*Ly];
constraints(4,:) = [1,1, 3/10*Lx,3/10*Lx, 0,0];
constraints(5,:) = [1,1, 7/10*Lx,7/10*Lx, 0,0];
constraints(6,:) = [1,1, Lx,Lx, 0,2/5*Ly];
sizeConstraints = size(constraints);
for i = 1:sizeConstraints
    fix = constraints(i,1:2); 
    xrange = constraints(i,3:4);
    yrange = constraints(i,5:6);
    Problem = Problem.constraint(fix, xrange, yrange);
end
%--------------------------------------------------------------------------
%% IMPOSE EXTERNAL LOADS
% concentrated load = [ [coordX,coordY], [xLoad, yLoad]]
% distributed load  = [ [xmin, xmax], [ymin, ymax], xLoadDensity,
%                                                   yLoadDensity ]
%------------------------

% Problem = Problem.addConcLoad([Lx/2,Ly], [0,-1e4]);
%------
Problem = Problem.addDistrLoad([0,Lx],[Ly,Ly],[0, -10e4/Lx]);

%--------------------------------------------------------------------------
%% INITIALIZE OPTIMIZER AND SOLVER
%--------------------
x_min = 1e-3; x_max = 1; maxstep = 0.3;
Optimizer = MMA(x_min, x_max, maxstep);
gamma(1:Nelem,1) = Vr_min;
countVol = 0;


% check nodes
% hold on
% axis([0, Lx, 0, Ly]);
% for i = 1 : size(coords,1)
%     plot(coords(i),coords(i),'bo');
% end

% %check elements
% hold on
% axis([0, Lx, 0, Ly]);
% for i = 1 : size(Elements,2)
%     Elements(i).draw(1,Nodes);
% end
%% OPTIMIZATION LOOP
%--------------------------------------------------------------------------
S = zeros(Nelem,1);
loop = 0; %loop counter
change = 1;

% GOC parameters
lambda = ones(2,1); 
gold  = zeros(2,1);
%--------------------

[~, Problem]    = Problem.Solve(gamma);  
f0 = Problem.evalFunctional(gamma);
Problem.f_init = f0; % initial value of compliance for normalization

figure(1) 
Problem.PlotGeom;
tic;
SF = 1;
%-----------------------------------
while (loop < maxIt) %&& ~(loop > 30 && change <= 0.11 && SF < 0.8 && SF > 0.6)
    %---------------------------------------
    %%% SOLVE THE CURRENT MECHANICAL PROBLEM
    %---------------------------------------
    loop = loop + 1;
    xold = gamma;
    f0_old = f0;
    if loop ~= 1
        [~, Problem]    = Problem.Solve(gamma);             % global displacement vector U
    end
    %---------------------------------------
    %%% EVALUATE FUNCTIONAL AND CONSTRAINTS
    %---------------------------------------   
    [f0, df0, f, df, Vol] = Problem.evaluate(gamma, Vr_min, Vr_max);
    [df0]   = Problem.check(gamma,df0);
    %---------------------------------------
    %%% UPDATE DESIGN VARIABLE
    %---------------------------------------
    %1 % OPTIMALITY CRITERIA METHOD

    [gamma]    = OC(gamma,df0, df(1,:), @(x) Problem.evalConstraints(x), isUniform, Vr_max); 

    %2  MMA method
%     [gamma]    = Optimizer.solve(f0, df0, f, df, gamma);

    %3 GOC METHOD
%     [lambda,gold,gamma] = GOC(Nelem,lambda,f,df,gold,gamma,df0);
    
     %---------------------------------------
      countVol = countVol +1;
      Smax = Problem.maxStress;
      SF = Smax / Yield_S^2;
      if loop > 40 && countVol > 2
      if SF < 0.7 && (Vr_max > Vmin)
        Vr_max = Vr_max - 0.01;
        if Vr_max < Vr_min
            Vr_min = Vr_max - 0.02;
        end
        countVol = 0;
      elseif SF > 0.8
        Vr_min = Vr_min + 0.01;
        if Vr_max-Vr_min < 5e-2 
            Vr_max = Vr_max + 0.02;
        end
        countVol = 0;
      end
      end
    %
    %---------------------------------------
    % PRINT RESULTS
    change = max(max(abs(gamma-xold)));
    disp([' It.: '  sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',f0) ...
          ' Vol fract: ' sprintf('%6.3f', Vol/V_0) ...
          ' stress:' sprintf('%10.4f',sqrt(Smax)) ...
          ' ch.: '  sprintf('%6.3f',change ) ...
          ' SF:'  sprintf('%.4f', SF) ])
    figure(1)
    Problem.Plot(gamma);
    %----------------------------------------------------------------------
end
toc;
%% POST FILTER
threshold = 3e-1;
xnew = gamma>threshold;
figure(2)
Problem.Plot(xnew);
[f0, df0, f, df, Vol] = Problem.evaluate(xnew, Vr_min, Vr_max);
change = max(max(abs(gamma-xold)));
    disp([' It.: '  sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',f0) ...
          ' Vol fract: ' sprintf('%6.3f', Vol/V_0) ...
          'stress:' sprintf('%10.4f',sqrt(Smax)/10^6) ...
          ' ch.: '  sprintf('%6.3f',change ) ...
          'SF:'  sprintf('%10.4f', SF) ])
%--------------------------------------------------------------------------
%% PRINT CONSTRAINTS AND LOADS
%------------------------
figure(2);
hold on;
Problem.PlotGeom;
hold off;