classdef TopOpt
    %TOPOPT Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        penal = 3;
        NDOF = 2;
        %---------
        Constraints;
        %---------
        Loads;
        %---------
        Nodes;
        Elements;
        Props;
        %---------
        V_0;
        nelx;
        nely;
        Lx;
        Ly;
        dimProblem;
        f_init;
    end
    
    methods (Access = public)
        function this = TopOpt(nelx, nely, Lx, Ly, V_0)
            this.nelx   = nelx;
            this.nely   = nely;
            this.Lx     = Lx;
            this.Ly     = Ly;
            this.V_0    = V_0;
        end
        %------------------------------------------------------------------
        %% CREATE MESH
        %---------------
        function this = buildMesh(this)
            %-----------------------
            % UNIFORM DISCRETIZATION
            %-----------------------           
            xcoords = linspace(0,this.Lx,this.nelx+1); ycoords = linspace(0,this.Ly,this.nely+1);
            [xcoords,ycoords]  = meshgrid(xcoords,ycoords);
            coords  = [reshape(xcoords,[],1),reshape(ycoords,[],1)];
            this.Nodes = Node.empty(size(coords,1),0);
            for inode = 1 : size(coords,1)
                this.Nodes(inode) = Node(inode, coords(inode,:));
            end
            this.Nodes = this.Nodes';
            %-------------------
            this.dimProblem      = 0;
            for inode = 1:length(this.Nodes)
                this.dimProblem = this.dimProblem + this.NDOF;
            end
            %-----------------------
            % BUILD ELEMENTS
            %-----------------------
            FstColId = zeros(2,1); SecColId = zeros(2,1);
            iel = 0;
            a = this.Lx/this.nelx/2;
            b = this.Ly/this.nely/2;
            this.Elements = RectBeam.empty(this.nelx*this.nely,0);
            for elx = 1:this.nelx
                for ely = 1:this.nely
                    iel = iel + 1;
                    %---------------
                    FstColId(1) = (elx-1)*(this.nely+1) + ely;
                    FstColId(2) = FstColId(1) + 1;
                    SecColId(1) = elx*(this.nely+1) + ely;
                    SecColId(2) = SecColId(1) + 1;
                    verteces    = [FstColId(1);SecColId;FstColId(2)];
                    %---------------
                    this.Elements(iel) = RectBeam(verteces,1, a, b);
                    
                    for iloc = 1 : length(verteces)
                        inode = verteces(iloc);
                        this.Nodes(inode).addElements(iel);
                    end
                end
            end
            this.Elements = this.Elements';
            %-----------------------
        end
        %------------------------------------------------------------------
        %% CREATE PROPERTY
        %-----------------------
        function this = createProp(this, id, E, nu,t)
            this.Props = [this.Props; Property(id,E,nu,t)];
        end
        %------------------------------------------------------------------
        %% SET BOUNDARY CONDITIONS
        %-------------------------
        function this = constraint(this, dof, xrange, yrange)
            %-------------
            % dof       : 1x2 array, ones on the dofs to fix
            % xrange    : x coords range of points to constrain
            % yrange    : y coords range of points to constrain
            %-------------
            tolx = this.Lx/this.nelx/2;
            toly = this.Ly/this.nely/2;
            if length(xrange) == 1
                xrange = [xrange-tolx, xrange+tolx];
            end
            if length(yrange) == 1
                yrange = [yrange-toly, yrange+toly];
            end
            %---------------------
            nodes = zeros(length(this.Nodes),1);
            count = 0;
            foundsomething = false;
            for inode = 1:length(this.Nodes)
                loccoord = this.Nodes(inode).x;
                if loccoord(1) >= xrange(1) && loccoord(1)<=xrange(2) ...
                   && loccoord(2) >= yrange(1) && loccoord(2) <= yrange(2)
                    count = count + 1;
                    foundsomething = true;
                    nodes(count) = inode;
                end
            end
            nodes = nodes(1:count);
            this.Constraints = [this.Constraints, Constraint(nodes,dof)];
            if ~foundsomething
                warning('no points in the provided range for BC');
            end
        end
        %------------------------------------------------------------------
        %% SET LOADS
        %------------------------------------------------------------------
        function this = addConcLoad(this, position, load)
            %-------------
            % dof       : 1x2 array, ones on the dofs to fix
            % position  : [x,y] coordinates of load point
            % load      : 1x2 load array
            %-------------
            % load to the closest node up to a certain tolerance
            tolx = this.Lx/this.nelx/2;
            toly = this.Ly/this.nely/2;
            incumb_dist = 2*max(this.Lx,this.Ly);
            for inode = 1 : length(this.Nodes)
                loccoord = this.Nodes(inode).x;
                curr_dist = sqrt(sum((loccoord - position).^2));
                if curr_dist < incumb_dist
                    incumb_dist = curr_dist;
                    incumb_node = inode;
                elseif curr_dist == incumb_dist
                    incumb_node = [incumb_node, inode];
                end
            end
            if incumb_dist > 2*max(tolx,toly)
                warning('no points near the presribed load position');
                return;
            end
            this.Loads = [this.Loads, Load('concentrated', incumb_node, load/length(incumb_node))];
        end
        %------------------------------------------------------------------
        function this = addDistrLoad(this, xrange, yrange, load)
            %-------------
            % dof       : 1x2 array, ones on the dofs to fix
            % xrange    : x coords range of points
            % yrange    : y coords range of points
            % load      : load linear density [N/m]
            %-------------
            dist = norm([xrange(1), yrange(1)] - [xrange(2), yrange(2)]);
            totLoad = load*dist;
            tolx = this.Lx/this.nelx/2;
            toly = this.Ly/this.nely/2;
            if xrange(1) == xrange(2)
                xrange = [xrange(1)-tolx, xrange(1)+tolx];
            end
            if yrange(1) == yrange(2)
                yrange = [yrange(1)-toly, yrange(1)+toly];
            end
            %---------------------
            nodes = zeros(length(this.Nodes),1);
            count = 0;
            foundsomething = false;
            for inode = 1:length(this.Nodes)
                loccoord = this.Nodes(inode).x;
                if loccoord(1) >= xrange(1) && loccoord(1)<=xrange(2) ...
                   && loccoord(2) >= yrange(1) && loccoord(2) <= yrange(2)
                    count = count + 1;
                    foundsomething = true;
                    nodes(count) = inode;
                end
            end
            nodes = nodes(1:count);
            if ~foundsomething
                warning('no points near the presribed load position');
                return;
            end
            this.Loads = [this.Loads, Load('distributed',nodes, totLoad/length(nodes))];
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------
        function [u, this] = Solve(this, x)
            % STEP 01: stiffness assembly
            K = this.assembly(this.Elements, x);
            % STEP 02: loads and constraints assembly
            [F, fix] = this.loadsAssembly(K);
            % STEP 03. solver
            u = this.solver(K, F, fix);
            % step 04: outputs (sollecitazioni)
            this = this.setOutputs(u);
        end
        %------------------------------------------------------------------
        %% PLOT MESH
        %------------------------------------------------------------------
        function plotMesh(this)
            for iel = 1:length(this.Elements)
                elements(iel).draw(this.Nodes)
            end
        end
        %-------------------------------------
        %% EVALUATE FUNCTIONAL AND CONSTRAINTS
        %-------------------------------------
        function f0 = evalFunctional (this,x)
            f0 = 0;
            for iel = 1:length(this.Elements)
                prop = this.Props(this.Elements(iel).idp);
                KE   = this.Elements(iel).stiffness(prop);
                Ue = this.Elements(iel).u;
                f0 = f0 + x(iel)^this.penal*Ue'*KE*Ue;
            end
        end
        %-------------------------------------
        function [f, Vol] = evalConstraints (this,x, Vr_min, Vr_max)
            %--------------------------------------------------------------
            %%% CONSTRAINTS DEFINITION
            %--------------------------------------------------------------
            %%% volume constraint
            %--------------------
%             func = @(x) log(x+1)/log(2);
            func = @(x) x;
            n = 1; 
            
            Vol = 0;
            Nelem = length(this.Elements);
            for iel = 1 : Nelem
                Vol = Vol + repfunc(func,n,x(iel))*this.Elements(iel).getArea;
            end
            f    = zeros(2,1);
            f(1) = (Vol/this.V_0 - Vr_max); % already normalized
            f(2) = (Vr_min - Vol/this.V_0); % already normalized
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        function [f0, df0, f, df, Vol] = evaluate(this,x, Vr_min, Vr_max)
            Nelem = length(this.Elements);
            df0 = zeros(Nelem,1);
            f0 = 0;
            for iel = 1:Nelem
                prop = this.Props(this.Elements(iel).idp);
                KE   = this.Elements(iel).stiffness(prop);
                Ue = this.Elements(iel).u;
                f0 = f0 + x(iel)^this.penal*Ue'*KE*Ue;
                df0(iel) = df0(iel) - this.penal*x(iel)^(this.penal-1)*Ue'*KE*Ue;
            end
            %-------------------
                %%% NORMALIZE
                %-------------------
                f0  = f0  / this.f_init;
                df0 = df0 / this.f_init;
            %--------------------------------------------
            %%% EVAL CONSTRAINTS VALUE AND SENSITIVITIES
            %--------------------------------------------
            [f, Vol] = evalConstraints (this,x, Vr_min, Vr_max);
             %--------------------------------------------------------------
            %%% CONSTRAINTS DERIVATIVE
            %--------------------------------------------------------------
            % volume constraint
            df  = zeros(2 , Nelem);
%             dfunc = @(x) 1/log(2)/log(x+1);
%             func = @(x) log(x+1)/log(2);
            n = 1;
            dfunc = @(x) 1;
            func = @(x) x;
            for iel = 1 : Nelem
                df(1,iel) =  drepfunc(dfunc,func,n,x(iel))*this.Elements(iel).getArea/this.V_0;
                df(2,iel) = -drepfunc(dfunc,func,n,x(iel))*this.Elements(iel).getArea/this.V_0;
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%%%%%%%%% MESH-INDEPENDENCY FILTER %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %------------------------------------------------------------------
        function [dcn]=check(this,gamma,dc)
          %-----------------------------
          % gamma = current vector of elemental densities
          % dc    = current compliance gradient
          %-----------------------------
          Nelem = length(this.Elements);
          dcn = zeros(Nelem,1); % filtered compliance gradient
          for iel = 1 : Nelem
              el = this.Elements(iel);
              sum = 0.0;
              for iloc = 1 : length(el.idn)
                  inode = el.idn(iloc);
                  node  = this.Nodes(inode);
                  for elloc = 1 : length(node.ConnectedElId)
                      weigth = 1/4;
                      jel   = node.ConnectedElId(elloc);
                      dcn(iel) = dcn(iel) + weigth*gamma(jel)*dc(jel);
                      sum = sum + weigth;
                  end
              end
              dcn(iel) = dcn(iel)/(gamma(iel) * sum);
          end
          %-------------------------------
        end
        %------------------------------------------------------------------
        %% FIND MAXIMUM STRESS
        %-------------------------------
        function Smax = maxStress(this)
            %---------------------------
            Smax = 0;
            for iel = 1:length(this.Elements)
                sigma = this.Elements(iel).stress(this.Props);
                VonMises = abs(sigma(1)^2 + sigma(2)^2 - sigma(1)*sigma(2) + 3*sigma(3)^2);
                if VonMises > Smax
                    Smax = VonMises;
                end
            end
        end
        %------------------------------------------------------------------
        %% PLOT RESULTS
        %----------------
        function PlotGeom(this)
            axis("equal");
            axis([[-0.15 1.15]*this.Lx, [-0.15 1.15]*this.Ly]);
            hold on
            %-----------------
            % plot borders
            plot([0,this.Lx,this.Lx,0, 0], [0, 0, this.Ly, this.Ly, 0], 'k-');
            % plot constraints
            for icon = 1 : length(this.Constraints)
                Cons = this.Constraints(icon);
                Style = "b";
                if Cons.fix(1) == 1 && Cons.fix(2) ~= 1
                    Style = Style + "_";
                elseif Cons.fix(1) ~= 1 && Cons.fix(2) == 1
                    Style = Style + "|";
                elseif Cons.fix(1) == 1 && Cons.fix(2) == 1
                    Style = Style + "+";
                end
                for inode = 1 : length(Cons.Nodes)
                    node = this.Nodes(Cons.Nodes(inode));
                    plot(node.x(1), node.x(2), Style, 'MarkerSize', 5);
                end
            end
            % plot loads
            for iload = 1 : length(this.Loads)
                Load = this.Loads(iload);
                for inode = 1 : length(Load.Nodes)
                    node = this.Nodes(Load.Nodes(inode));
                    if Load.type == "distributed"
                        load = Load.load/10;
                    elseif Load.type == "concentrated"
                        load = Load.load/70;
                    end
%                     forceNorm = norm(Load.load);
                    fUp = node.x - [load(1), load(2)];
%                     plot([fDown(1), fUp(1)], [fDown(2),fUp(2)], 'r', 'lineWidth', 1.5);
                    q = quiver(fUp(1), fUp(2), load(1), load(2), 'r', 'lineWidth', 1.5);             
                end
            end
            hold off
        end
        function [] = Plot(this,x)
            hold on
            a = linspace(0,this.Lx, this.nelx);
            b = linspace(0,this.Ly, this.nely);
            [X,Y] = meshgrid(a,b);
            x2 = reshape(x,[this.nely,this.nelx]);
            contourf(X,Y,x2);
            hold on;
            colormap(flipud(gray));
            caxis([0 1]);
            cd = colorbar;
            hold off;
        end
        
    end
    %----------------------------------------------------------------------
    %%% PRIVATE METHODS!!
    %-------------------------------
    methods (Access = private)
        %------------------------------------------------------------------
        %% ASSEMBLY
        %------------------------------------------------------------------
        function [K] = assembly(this, elements, x)
            %-------------------------
            dim = size(elements, 1);
            %--------------------------
            K_val = zeros(dim*4*4*3*3,1);
            i_index = zeros(dim*4*4*3*3,1);
            j_index = zeros(dim*4*4*3*3,1);
            it = 0;
            %---------------
            for e = 1 : dim
                elem = elements(e);
                totelnodes = size(elem.idn, 1); % UTILE SE USO ELEMENTI CON NUMERI DI NODI DIVERSI
                pos = zeros(totelnodes, 1);
                for i = 1:totelnodes
                    pos(i) = elem.idn(i);
                end
                prop = this.Props(elem.idp);
                elK = x(e)^this.penal * elem.stiffness(prop);
                for nodeRow = 1: totelnodes
                    posRow = pos(nodeRow);
                    for nodeCol = 1: totelnodes
                        posCol = pos(nodeCol);
                        for i=1:this.NDOF
                            % nodeRow numerazione locale
                            % posRow numerazione globale
                            row = this.NDOF * (posRow -1) + i;
                            rowE1 = this.NDOF * (nodeRow- 1) + i;
                            for j=1:this.NDOF
                                col = this.NDOF * (posCol - 1) + j;
                                colE1 = this.NDOF * (nodeCol- 1) + j;
                                it = it + 1;
                                i_index(it) = row;
                                j_index(it) = col;
                                K_val(it)   = elK(rowE1, colE1);
                            end
                        end
                    end
                end
            end
            %-------------------
            K_val = K_val(1:it); 
            i_index = i_index(1:it); j_index = j_index(1:it);
            %-------------------
            K = sparse(i_index,j_index,K_val);
            %----------------------------------
        end
        %------------------------------------------------------------------
        function [F, fix] = loadsAssembly(this, K)
            %----------------------------------------
            % CONSTRAINT
            %-----------
            count = 0;
            fix = zeros(length(this.Constraints)*2,1);
            for icon = 1 : length(this.Constraints)
                constraint = this.Constraints(icon);
                for iloc = 1:length(constraint.Nodes)
                    node = constraint.Nodes(iloc);
                    for dof = 1:this.NDOF
                        if constraint.fix(dof) == 1
                            count = count + 1;
                            fix(count) = (node-1)   * this.NDOF + dof;
                        end
                    end
                end
            end
            fix = fix(1:count);
            %------------------
            % LOADS 
            %--------
            F = zeros(this.dimProblem,1);
            for iload = 1 : length(this.Loads)
                load = this.Loads(iload);
                for iloc = 1 : length(load.Nodes)
                    node = load.Nodes(iloc);
                    for dof = 1:this.NDOF
                        F((node-1) * this.NDOF + dof) = ...
                                   F((node-1) * this.NDOF + dof) +load.load(dof);
                    end
                end
            end
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        function [u] = solver(this, K, F, fix)
            K(:,fix) = [];
            K(fix,:) = [];
            F(fix)   = [];
            fixval = sparse(fix,1,1,this.dimProblem,1);
            u = zeros(this.dimProblem,1);
            if (~isempty(F)) % Ho vincolato tutti i dof del problema
                x = K \ F;
                cont = 1;
                for i = 1:this.dimProblem
                    if (fixval(i) == 0)
                        u(i) = x(cont);
                        cont = cont + 1;
                    end
                end
            end
        end
        %------------------------------------------------------------------
        %% SET OUTPUTS
        %------------------------------------------------------------------
        function this = setOutputs(this, u)
            for iel = 1 : length(this.Elements)
                locNodes = this.Elements(iel).idn;
                uloc     = zeros(length(locNodes)*this.NDOF,1);
                for iloc = 1:length(locNodes)
                    node = locNodes(iloc);
                    for dof = 1: this.NDOF
                        uloc((iloc-1)*this.NDOF+dof,1) = u((node-1) * this.NDOF + dof);
                    end
                end
                this.Elements(iel).u = uloc;
            end
        end
        %------------------------------------------------------------------
    end
end

