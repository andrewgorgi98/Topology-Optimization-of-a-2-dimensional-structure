classdef Node < handle
    %----------------------------------------------------------------------
    properties
        id;
        x = [];
        ConnectedElId = [];
        r = 15;
    end
    %----------------------------------------------------------------------
    methods 
        
        function this = Node(id, x) 
            this.id = id;
            this.x = x;
        end
        %------------------------------------------------------------------
        function this = addElements(this, idel)
            this.ConnectedElId = [this.ConnectedElId, idel];
        end
        %------------------------------------------------------------------
        function [dist] = distance(this, node)
            dist = sqrt((node.x(1)-this.x(1))^2+...
                        (node.x(2)-this.x(2))^2);
        end
        %------------------------------------------------------------------
        function [alpha] = angle(this, node)
            a = node.x(1) - this.x(1);
            b = node.x(2) - this.x(2);
            alpha = pi / 2.0;
            if (a ~= 0.0)
                alpha = atan(b /a);
            end
        end
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        function write(this)
            fprintf('-Node ID: %i\n', this.id);
            fprintf('   coord: [%f\t%f]\n', this.x(1), this.x(2));
            fprintf('-- \n');
        end
        %------------------------------------------------------------------
        function draw(this, idFig)
            scale = 5;
            figure(idFig);
            hold on
            plot(this.x(1), this.x(2), '.g', 'MarkerSize', 2*this.r)
            %
            if (this.fix(1) == 1) 
                X = [(this.x(1)-scale * this.r), this.x(1)];
                Y = [this.x(2)            , this.x(2)];
                type= '-b';
                if (this.u(1) ~= 0.0)
                    type = '-c';
                end
                plot(X, Y, type, 'LineWidth', 2)
            end
            %
            if (this.fix(2) == 1) 
                X = [this.x(1)            , this.x(1)];
                Y = [this.x(2) - scale * this.r           , this.x(2)];
                type= '-b';
                if (this.u(1) ~= 0.0)
                    type = '-c';
                end
                plot(X, Y, type, 'LineWidth', 2)
            end
            F =sqrt(this.load' * this.load);
            if (F ~= 0.0)
                f = [this.load(1) / F; this.load(2) / F];
                X = [this.x(1), this.x(1) + f(1) *2 * this.r];
                Y = [this.x(2), this.x(2) + f(2) *2 * this.r];
                hold on
                quiver(this.x(1), this.x(2),...
                    f(1) * scale * this.r, f(2) * scale * this.r, 5, 'LineWidth', 2)
%                 line(X, Y, 'Color', 'red', 'LineWidth', 2);
%                 plot(X(2), Y(2), '>', 'MarkerSize', 4)
            end
        end
    end
    %----------------------------------------------------------------------
    %----------------------------------------------------------------------
end