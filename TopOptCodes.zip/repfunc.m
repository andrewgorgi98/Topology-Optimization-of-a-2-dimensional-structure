function gunc = repfunc(func, n, x)
% evaluate funtion func(x) over itself n-times
gunc = x;
for i = 1:n
    old  = gunc;
    gunc = func(old);
end
end

