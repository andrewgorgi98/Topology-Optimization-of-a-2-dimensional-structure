classdef Load
    %LOADCASE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        type;
        load;
        Nodes;
    end
    
    methods
        function this = Load(type, nodes,load)
            this.type = type;
            this.load = load;
            this.Nodes = nodes;
        end
        
    end
end

