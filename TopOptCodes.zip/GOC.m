function [lambda,gold,xnew] = GOC(Nelem,lambda,g,dg,gold,x,dc)
%------------------------------------
eps = 0.05; maxmove = 0.2;
deltag = g - gold; gold = g;
xnew = zeros(length(x),1);
%--------------------
for i = 1 : length(g)
    if (g(i) > 0 && deltag(i) > 0) || (g(i) < 0 && deltag(i) < 0), p0 = 1.0;
    elseif (g(i) > 0 && deltag(i) > -eps) || (g(i) < 0 && deltag(i) < eps), p0 = 0.5;
    else, p0 = 0;
    end
    lambda(i) = lambda(i)*(1 + p0*(g(i) + deltag(i)));
end
%--------------------
for iel = 1: Nelem
    numerator   = 0;
    denominator = 0;
    if dc(iel) < 0
        numerator = dc(iel);
    else
        denominator = dc(iel);
    end
    for i = 1 : length(g)
        if dg(i,iel) < 0
            numerator = numerator + lambda(i)*dg(i,iel);
        else
            denominator = denominator + lambda(i)*dg(i,iel);
        end
    end
    De = - numerator/denominator;
    xnew(iel) = max(0.001,max(x(iel) - maxmove,min(1.,min(x(iel) + maxmove,x(iel).*sqrt(De)))));
end
%------------------------------------
end

