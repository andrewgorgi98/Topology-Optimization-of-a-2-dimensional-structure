classdef RectBeam < handle
    %----------------------------------------------------------------------
    properties
        idn = []; % tutti gli indici (GLOBALI) dei nodi (non le loro coordinate)
        idp % indice di proprietà
        strain; % deformazione
        sigma; 
        axial; 
        a;
        b;
        u; % 4NDOF x 1, array
    end
    %----------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        function this = RectBeam(nodes, prop, a, b)
            this.idn = nodes;
            this.idp = prop;
            this.strain  = 0.0;
            this.sigma   = 0.0;
            this. axial  = 0.0;
            this.a       = a;
            this.b       = b;
        end
        %------------------------------------------------------------------
        %% LOCAL STIFFNESS MATRIX
        %------------------------------------------------------------------
        function [Kloc] = localStiffness(this,E,nu)
            a = this.a;
            b = this.b;
%             a = 1;
%             b = 1;
            k = [   4*(2*b^2+a^2*(1-nu)); ...
                    3*a*b*(1+nu); ...
                    2*(a^2*(1-nu)-4*b^2); ...
                    3*a*b*(3*nu-1); ...
                    2*(a^2*(nu-1)-2*b^2); ...
                    3*a*b*(-nu-1); ...
                    4*(b^2-a^2*(1-nu)); ...
                    3*a*b*(1-3*nu); ...
                    4*(2*a^2+b^2*(1-nu)); ...
                    4*(a^2-b^2*(1-nu)); ...
                    2*(b^2*(nu-1)-2*a^2); ...
                    2*(b^2*(1-nu)-4*a^2);];

            Kloc = E/(24*(1-nu^2)*a*b)*[k(1) k(2)  k(3) k(4)  k(5) k(6)  k(7) k(8)
                                        k(2) k(9)  k(8) k(10) k(6) k(11) k(4) k(12)
                                        k(3) k(8)  k(1) k(6)  k(7) k(4)  k(5) k(2)
                                        k(4) k(10) k(6) k(9) k(8) k(12) k(2) k(11)
                                        k(5) k(6)  k(7) k(8)  k(1) k(2)  k(3) k(4)
                                        k(6) k(11) k(4) k(12) k(2) k(9) k(8) k(10)
                                        k(7) k(4)  k(5) k(2)  k(3) k(8)  k(1) k(6)
                                        k(8) k(12) k(2) k(11) k(4) k(10) k(6) k(9)];
                                    
                                    
% k=[ 1/2-nu/6   1/8+nu/8 -1/4-nu/12 -1/8+3*nu/8 ... 
%    -1/4+nu/12 -1/8-nu/8  nu/6       1/8-3*nu/8];
% Kloc1 = [ k(1) k(2) k(3) k(4) k(5) k(6) k(7) k(8)
%                   k(2) k(1) k(8) k(7) k(6) k(5) k(4) k(3)
%                   k(3) k(8) k(1) k(6) k(7) k(4) k(5) k(2)
%                   k(4) k(7) k(6) k(1) k(8) k(3) k(2) k(5)
%                   k(5) k(6) k(7) k(8) k(1) k(2) k(3) k(4)
%                   k(6) k(5) k(4) k(3) k(2) k(1) k(8) k(7)
%                   k(7) k(4) k(5) k(2) k(3) k(8) k(1) k(6)
%                   k(8) k(3) k(2) k(5) k(4) k(7) k(6) k(1)];
        end
        %------------------------------------------------------------------
        function [R] = rotmat(~, alpha)
            s = sin(alpha);
            c = cos(alpha);
            r = [c -s;
                 s,  c];
            z = [0 0;
                 0 0;];
            R = [r z;
                z r;];
        end
        %------------------------------------------------------------------
        function [K] = stiffness(this, prop)
            % ns : solo nodi dell'elemento
            % prop: solo pro dell'elemento
            %...
            E = prop.young;
            nu = prop.nu;
            Kloc = prop.t*this.localStiffness(E, nu);
            K = Kloc;
        end
        %------------------------------------------------------------------
       
        %------------------------------------------------------------------
        function setOutput(this, ns, prop)
            E  = prop.young;
            A  = prop.area;
            l0 = ns(1).distance(ns(2));
            x1 = ns(1).x + ns(1).u;
            x2 = ns(2).x + ns(2).u;
            l  = sqrt((x2(1) - x1(1))^2 + (x2(2) - x1(2))^2);
            this.strain = (l-l0) / l0;
            this.stress = this.strain * E;
            this.axial = this.stress * A;
            ns(1).x=x1; ns(2).x=x2;
        end
        %------------------------------------------------------------------
        
        function draw(this, nodes) % mi servono le coordinate dei nodi
            hold on
            n01 = nodes.coords(this.idn(1));
            n02 = nodes.coords(this.idn(2));
            n04 = nodes.coords(this.idn(3));
            n03 = nodes.coords(this.idn(4));
            N = [n01;n02;n03;n04];
            
            for i = 1:4
                plot([N(i,1), N(mod_n(i+1,4),1)], ...
                 [N(i,2), N(mod_n(i+1,4),2)], ...
                 'k', 'LineWidth', 3)
            end
        end
        %------------------------------------------------------------------
        function sigma = stress(this, Props)
            E  = Props(this.idp).young;
            nu = Props(this.idp).nu; 
            D = E/((1-nu)^2)*[1   nu    0;
                nu  1     0;
                0   0 (1-nu)/2];
            t0 = zeros(4,3);
            count = 1;
            x = [-this.a, this.a]; y=[-this.b, this.b];
            for i = 1:2
                for j = 1:2
                    t0(count,:) = this.bmat(x(i),y(j))*this.u;
                    count = count + 1;
                end
            end
            t = max(abs(t0))';
            sigma  = D*t;
            this.sigma = sigma;
        end
        %------------------------------------------------------------------
        function A = getArea(this)
            A = 4*this.a*this.b;
        end
        %-----------------------------------------------------------------
        function B = bmat(this, x, y)
            a = this.a; b = this.b;
        B = 1/(4*a*b)*[-(b-y)    0    (b-y)    0    (b+y)    0   -(b+y)    0   ;
                    0   -(a-x)    0   -(a+x)    0    (a+x)    0    (a-x) ;
                 -(a-x) -(b-y) -(a+x)  (b-y)  (a+x)  (b+y)  (a-x) -(b+y)];
        end
    end
    %----------------------------------------------------------------------
end

