function dgunc = drepfunc(dfunc,func,n,x)
% evaluate derivative of gunc, repetition of func over itself n times
%--------------
old   = x;
dgunc = 1;
%--------------
for i = 1:n
    dgunc = dgunc * dfunc(old);
    old   = func(old);
end
%--------------
end