clc;
clear;
close all;

onlyNS = 0; %1 to solve only NS equations, 0 to solve the whole optimization problem

project = TopologyOptimizationProject(onlyNS);
project = project.launchProblem();
% 
TopologyOptimizationProject.saveVariablesResults(project.problem, project.u1, project.u2, project.p, project.gamma);
project.createMeshNodes();
project.createSolutions();


matSol = strcat('mesh_COMSOL\', project.problem, '\', project.problem, '_mat_sol.txt');
comSol = strcat('mesh_COMSOL\', project.problem, '\', project.problem, '_com_sol.txt');
[eu1, eu1r, eu2, eu2r, ep, epr] = TopologyOptimizationProject.compareSolutions(project, matSol, comSol);