classdef ADJOINT < Stokes
    %UNTITLED3 Summary of this class goes here
    %   Detailed explanation goes here

    properties
        uh1;
        uh2;
        ph;
        alpha;
        rho;
        func_id;
    end

    methods (Access = public)
        function this = ADJOINT(solver, mu, rho, func_id)
%             this@SolverStokesP1P2();
            this     = this.copy(solver);
            this.mu  = mu;
            this.rho = rho;
            this.func_id = func_id;
            this.V.NeuVal = sparse(2*solver.V.Nodes,2*solver.V.Nodes);
        end
        %% UPDATE
        function this = Update(this, uh1, uh2, ph, alpha)
            this.uh1 = uh1;
            this.uh2 = uh2;
            this.ph  = ph;
            this.alpha = alpha;
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A      = this.mu * this.LinSys.A;
            M      = -c * this.LinSys.M;
            M_alpha = BuildMalpha(this);
            B1     = this.LinSys.B1;
            B2     = this.LinSys.B2;

            SYSMAT=[A+M+M_alpha                      ,sparse(this.V.Nodes,this.V.Nodes), B1';
                    sparse(this.V.Nodes,this.V.Nodes), A+M+M_alpha                     , B2';
                    B1                               , B2                              , sparse(this.P.Nodes,this.P.Nodes)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% ADJOINT DIRICHLET BC
        %------------------------------------------------------------------
        function this = setDirBC(this, direction, range, fixcoord, value)
            %METHOD1 Summary of this method goes here
            %   direction: 1 -> x direction (upper/lower wall)
            %              2 -> y direction (left/right wall)
            %   range    : 2x1 array, range of chosen coordinates
            %   fixvalue : value of the fixed coord
            %   value    : vector
            %--------------------------------------------------------------
            BNodes = this.Bound.Nodes;
            coord = this.V.coord;
            %---------------
            switch direction
                case 1
                    limits = this.X_limits;
                case 2
                    limits = this.Y_limits;
            end
            %--------------
            if ~(ismember(fixcoord,limits))
                error('wrong coords for BC');
            end
            %----------
            
            for ibound = 1 : length(BNodes)
                iglob = BNodes(ibound);
                coord_node = coord(iglob,:);
                
                if (coord_node(mod_n(direction+1,2))==fixcoord   && ...
                                coord_node(direction) <= range(2) && ...
                                 coord_node(direction) >= range(1))
                     %--------
                    index = this.Bound.BCid(iglob);
                    switch this.Bound.Check(iglob)
                        case "Neu"
                            this = DeleteBC(this,"Neu",index);
                            this.Bound.Check(iglob) = "Dir";
                            this.V.DirNod = [this.V.DirNod, iglob];
                            index = length(this.V.DirNod);
                            this.Bound.BCid(iglob) = index;
                        case "Dir"

                        otherwise
                            this.Bound.Check(iglob) = "Dir";
                            this.V.DirNod = [this.V.DirNod, iglob];
                            index = length(this.V.DirNod);
                            this.Bound.BCid(iglob) = index;
                    end
                    this.V.DirVal(index,:) = value;
                end
            end
            %--------------------------------------------------------------   
            this.V.NDir = size(this.V.DirNod,2);
        end
        function this = setEdgeDirBC(this, bound_id, func_val)
                    %METHOD1 Summary of this method goes here
                    %   bound_id : edge index (from COMSOL) to set BC
                    %   func_val : function on the boundary to get BC values
                    %------------------------------------------------------
                    coord = this.V.coord;
                    Bedges = this.Bound.Edges; 
                    BedgesId = this.Bound.EdgesId;
                    %---------------
                    for iedge = 1 : length(Bedges)
                        if (BedgesId(iedge) == bound_id)
                            for iloc = 1:2
                                iglob = Bedges(iedge, iloc);
                                index = this.Bound.BCid(iglob);
                                switch this.Bound.Check(iglob)
                                    case "Neu"
                                        this = DeleteBC(this,"Neu",index);
                                        this.Bound.Check(iglob) = "Dir";
                                        this.V.DirNod = [this.V.DirNod, iglob];
                                        index = length(this.V.DirNod);
                                        this.Bound.BCid(iglob) = index;
                                    case "Dir"
                    
                                    otherwise
                                        this.Bound.Check(iglob) = "Dir";
                                        this.V.DirNod = [this.V.DirNod, iglob];
                                        index = length(this.V.DirNod);
                                        this.Bound.BCid(iglob) = index;
                                end
                            this.V.DirVal(index,:) = func_val(coord(iglob,1), coord(iglob,2));
                            end
                        end
                    end
                    %--------------------------------------------------------------
                    ndir = size(this.V.DirNod,2);
                    this.V.NDir = ndir;
        end
        %------------------------------------------------------------------
        %% ADJOINT NEUMANN BC
        function this = setNeuBC(this, direction, range, fixcoord)
            %METHOD1 Summary of this method goes here
            %   direction: 1 -> x direction (upper/lower wall)
            %              2 -> y direction (left/right wall)
            %   range    : 2x1 array, range of chosen coordinates
            %   fixvalue : value of the fixed coord
            %   flux     : flux vector
            %--------------------------------------------------------------
            BEdges  = this.Bound.Edges;
            Nodes   = this.V.Nodes;
            %---------------
            switch direction
                case 1
                    limits = this.X_limits;
                    normal = [0, -1];
                    if fixcoord == limits(2)
                        normal = - normal;
                    end
                case 2
                    limits = this.Y_limits;
                    normal = [-1,0];
                    if fixcoord == limits(2)
                        normal = - normal;
                    end
            end
            %--------------
            if ~(ismember(fixcoord,limits))
                error('wrong coords for BC');
            end
            %--------------------------
            
                    
            for iedge = 1 : size(BEdges,1)
                length_edge = this.Bound.EdgesLength(iedge);
                for iloc = 1:2
                    iglob = BEdges(iedge,iloc);
                    coord_node = this.V.coord(iglob,:);   
                %----------
                if (coord_node(mod_n(direction+1,2))==fixcoord   && ...
                                coord_node(direction) <= range(2) && ...
                                 coord_node(direction) >= range(1))
                     %--------
                    switch this.Bound.Check(iglob)
                        case "Neu"
                        otherwise
                            index = this.Bound.BCid(iglob);
                            if this.Bound.Check(iglob) == "Dir"
                                this = DeleteBC(this,"Dir",index);
                            end
                            this.Bound.Check(iglob) = "Neu";
                            this.Bound.BCid(iglob) = iglob;
                    end
                    %-----------
                    for jloc = 1:2
                       jglob = BEdges(iedge,jloc);
                       value1 = (this.uh1(jglob)*normal(1) + this.uh2(jglob)*normal(2)) * ...
                                                   length_edge/2;
                       value2 = value1;
                       this.V.NeuVal(iglob,jglob) = this.V.NeuVal(iglob,jglob) + value1;
                       this.V.NeuVal(iglob+Nodes,jglob+Nodes) = this.V.NeuVal(iglob+Nodes,jglob+Nodes) + value2;
                    end
                end % end if
                %----------
                end % end for iloc
                %----------
            end % end for iedge              
        end
        %------------------------------------------------------------------
        function this = setEdgeNeuBC(this, bound_id)
            %METHOD1 Summary of this method goes here
            %   direction: 1 -> x direction (upper/lower wall)
            %              2 -> y direction (left/right wall)
            %   range    : 2x1 array, range of chosen coordinates
            %   fixvalue : value of the fixed coord
            %   flux     : flux vector
            %--------------------------------------------------------------
            Bedges    = this.Bound.Edges;
            BedgesId  = this.Bound.EdgesId;
            Nodes   = this.V.Nodes;
            uh = [this.uh1, this.uh2];

            i_sparse    = zeros(2*this.Bound.NBound,1);
            j_sparse    = zeros(2*this.Bound.NBound,1);
            tempNeu_val = zeros(2*this.Bound.NBound,1);
            count = 0;
            
            C = [ 1-1/sqrt(3), 1+1/sqrt(3) ] /2;
            u_edge = zeros(2,1);
            
            for iedge = 1 : size(Bedges,1)
                for iloc = 1:2                   
                %----------
                    if (BedgesId(iedge) == bound_id)
                        edge = Bedges(iedge,:);
                        iglob = edge(iloc);
                         %--------
                        length_edge = this.Bound.EdgesLength(iedge);
                        normal = this.Bound.ExtNormal(iedge,:);
                        
                        
                        u_edge(1) = (C(1)*uh(edge(1),:) + C(2) * uh(edge(2),:))*normal';
                        u_edge(2) = (C(2)*uh(edge(1),:) + C(1) * uh(edge(2),:))*normal';
                        
                        switch this.Bound.Check(iglob)
                            case "Neu"
                            otherwise
                                index = this.Bound.BCid(iglob);
                                if this.Bound.Check(iglob) == "Dir"
                                    this = DeleteBC(this,"Dir",index);
                                end
                                this.Bound.Check(iglob) = "Neu";
                                this.Bound.BCid(iglob) = iglob;
                        end
                        %-----------
                        for jloc = 1:2
                            jglob = edge(jloc);
                            %-----------------------
                            value1 = +(this.uh1(jglob)*normal(1) + this.uh2(jglob)*normal(2)) * ...
                                                   length_edge/2;
                                               
                            value2 = value1;
                            count = count + 1;
                            i_sparse(count) = iglob + Nodes;
                            j_sparse(count) = jglob + Nodes;
                            tempNeu_val(count) = value2;
                            %-------
                            
                            %-----------------------
                            count = count + 1;
                            i_sparse(count) = iglob;
                            j_sparse(count) = jglob;
                            tempNeu_val(count) = value1;
                        end
                    end % end if
                %----------
                end % end for iloc
                %----------
            end % end for iedge
            i_sparse    = i_sparse(1:count);
            j_sparse    = j_sparse(1:count);
            tempNeu_val = tempNeu_val(1:count);
            %------------------------------------------
            tempNeu = sparse(i_sparse,j_sparse,tempNeu_val,2*this.V.Nodes,2*this.V.Nodes);
            this.V.NeuVal = this.V.NeuVal + tempNeu;
                    
        end
        %------------------------------------------------------------------
        function this = clearBC(this)
            this.V.DirNod = [];
            this.V.DirVal = [];
            this.V.Ndir   = 0 ;
            this.Bound.Check(:) = "none";
            this.V.NeuNod = [];
            this.V.NeuVal = sparse(2*this.V.Nodes,2*this.V.Nodes);
            this.V.NNeu   = 0 ;
        end
        %------------------------------------------------------------------
        %%% PREPRO
        %------------------------------------------------------------------
        function this = Prepro(this)
            [rhs, P_bc] = forcing(this);
            this.LinSys.rhs  = rhs;
            this.LinSys.P_bc = P_bc;
        end
        %------------------------------------------------------------------
    end
        %------------------------------------------------------------------
    methods (Access = protected)
        %% IMPOSE BOUNDARY CONDITIONS
        function [stiffMat,rhs] = imposeBC(this,P_bc,stiffMat,rhs,flag)
            %--------------------------------------------------------------
            % impose Dirichle BCs
            % flag: 0 => penalty method;
            %     : 1 => Lifting function;
            if nargin < 5
                flag = 0;
            end
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            NDir_v   = this.V.NDir;
            DirNod_v = this.V.DirNod;
            DirVal_v = this.V.DirVal;
            %-----------------------
            %%% DIRICHLET
            %--------------------------------------------------------------
            switch flag 
                %----------------------------------------------------------
                case 0
                    %------------------------------------------------------
                    penalty=1e10;
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=penalty;
                            rhs((k-1)*Nodes_v+iglob)=penalty*DirVal_v(idir,k);
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                case 1
                    %------------------------------------------------------
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);   
                            stiffMat((k-1)*Nodes_v+iglob,:)=0; 
                            rhs=rhs-DirVal_v(idir,k)*stiffMat(:,(k-1)*Nodes_v+iglob); 
                            rhs((k-1)*Nodes_v+iglob)=DirVal_v(idir, k);
                            stiffMat(:,(k-1)*Nodes_v+iglob)=0;
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
            end
            %------------------------
            %%%% NEUMANN
            stiffMat(1:2*Nodes_v,1:2*Nodes_v) = stiffMat(1:2*Nodes_v,1:2*Nodes_v) + this.V.NeuVal;
            %--------------------------------------------------------------
            %%% ZERO MEAN PRESSURE CONDITION IF NO NEUMANN BC
            %--------------------------------------------------------------
            if sum(this.Bound.Check == "Neu") == 0
            stiffMat(2*Nodes_v+this.P.Nodes+1,1:2*Nodes_v)=0;
            stiffMat(2*Nodes_v+this.P.Nodes+1,2*Nodes_v+1:end)=P_bc;
            rhs(2*Nodes_v+this.P.Nodes+1)=0;
            stiffMat(2*Nodes_v+iglob,1:2*Nodes_v)=0;
            stiffMat(2*Nodes_v+iglob,2*Nodes_v+1:end)=P_bc;
            rhs(2*Nodes_v+iglob)=0;

            stiffMat(iglob,1:2*Nodes_v)=0;
            stiffMat(iglob,iglob)=1;
            rhs(iglob)=0;
            end
        end
        %% FORCING
        function [rhs, P_bc] = forcing(this)
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            triang_v = this.V.triang;
            Area_v   = this.V.Area;
            triang_p = this.P.triang;
            Area_p   = this.P.Area;
            rhs      = zeros(2*Nodes_v+this.P.Nodes,1);
            P_bc     = zeros(this.P.Nodes,1);
            %--------------------------------------------------------------
            for iel=1:this.V.Nelem
                %----------------------------------------------------------
                for iloc=1:3
                    iglob=triang_v(iel,iloc);
                    rhs(iglob)=rhs(iglob)+...
                        this.f_1(iglob)/3*Area_v(iel);
                    rhs(Nodes_v+iglob)=rhs(Nodes_v+iglob)+...
                        this.f_2(iglob)/3*Area_v(iel);
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            for iel=1:this.P.Nelem
                for iloc=1:3
                    iglob=triang_p(iel,iloc);
                    rhs(2*Nodes_v+iglob)=rhs(2*Nodes_v+iglob)+this.g(iglob)/3*Area_p(iel);
                    P_bc(iglob)=P_bc(iglob)+Area_p(iel)/3;
                end
            end
            %------------------
            if this.func_id ~= 1
                    rhs(1:Nodes_v)            = rhs(1:Nodes_v) - this.mu/this.rho*(this.LinSys.A + this.LinSys.HT1)/2*this.uh1;
                    rhs(Nodes_v+1: 2*Nodes_v) = rhs(Nodes_v+1: 2*Nodes_v) - this.mu/this.rho*(this.LinSys.A + this.LinSys.HT2)/2*this.uh2;
            end
            %--------------------------------------------------------------
        end
    end
    methods (Access=private)
        function this = DeleteBC(this, BCname,index)
            switch BCname
                case "Dir"
                    this.V.DirNod(index) = [];
                    this.V.DirVal(index,:) = [];
                    this.V.NDir = this.V.NDir-1;
                    for i = index:this.V.NDir
                        ibound = this.V.DirNod(i);
                        this.Bound.BCid(ibound) = this.Bound.BCid(ibound)-1;
                    end
                case "Neu"
                    this.V.NeuVal(index,:) = 0;
                    this.V.NNeu = this.V.NNeu-1;
            end
        end
    end
end