classdef RevisedStokes < Stokes
    %   SolverStokesP1P2 Solver of Stokes problem
    %   Find nodal values of solution (u,p) to 
    %   alpha(x)*u - /mu*/div /grad(u) + /grad(p) = f
    %                           div(u) = g 
    
    properties
        alpha;
    end
    
    methods (Access = public)
        %% CONSTRUCTOR
        %------------------------------------------------------------------
        function this = RevisedStokes(meshdir,nfig, mu, f_1, f_2, g, flag)
            %UNTITLED2 Construct an instance of this class
            %   Detailed explanation goes here
            this = this.initialize(meshdir,nfig, mu, f_1, f_2, g, flag);

        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A        = this.mu * this.LinSys.A;
            M        = c * this.LinSys.M;
            B1       = this.LinSys.B1;
            B2       = this.LinSys.B2;
            M_alpha  = BuildMalpha(this);

            SYSMAT=[A+M_alpha+M                      ,sparse(this.V.Nodes,this.V.Nodes), B1' ;
                    sparse(this.V.Nodes,this.V.Nodes), A+M_alpha+M                     , B2'  ;
                    B1                               , B2                              , sparse(this.P.Nodes,this.P.Nodes)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% SOLVER
        function [uh1, uh2, p] = solver(this)
            % SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %-------
            SYSMAT   = stiffBuild(this, c);
            flag = 1; % <= lifting function
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
    end
    methods (Access = protected)
         %------------------------------------------------------------------
         %------------------------------------------------------------------
    end
end

