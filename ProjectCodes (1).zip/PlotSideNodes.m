function PlotSideNodes(xLimits, yLimits, coords, b_nodes, b_nodes_id, side_id)

    colors = [1 0 0; 0 1 0; 0 0 1; 0 1 1; 1 0 1; 1 1 0; ...
        0.0000 0.4470 0.7410; 0.8500 0.3250 0.0980; 0.9290 0.6940 0.1250; ...
        0.4940 0.1840 0.5560; 0.4660 0.6740 0.1880; 0.3010 0.7450 0.9330; ...
        0.6350 0.0780 0.1840];
%     nCol = size(colors,1);
    colCont = 0;
    
    for locId = 1:length(side_id)
        sideNodes = zeros(length(b_nodes),1);
        sideNodesCoords = zeros(length(b_nodes),2);
        cont = 0;
        for i = 1:length(b_nodes)
            if b_nodes_id(i) == side_id(locId)
                cont = cont + 1;
                sideNodes(cont) = b_nodes(i);
                sideNodesCoords(cont,:) = coords(sideNodes(cont),:);
            end
        end
        limitX = [min(sideNodesCoords(1:cont,1)), max(sideNodesCoords(1:cont,1))];
        limitY = [min(sideNodesCoords(1:cont,2)), max(sideNodesCoords(1:cont,2))];
        midPoint = [mean(limitX), mean(limitY)];
        colCont = colCont + 1;
        plot(sideNodesCoords(1:cont,1), sideNodesCoords(1:cont,2), '.', 'Color', colors(colCont, :), 'LineWidth', 0.5)
        axis([xLimits(1) xLimits(2) yLimits(1) yLimits(2)])
        axis equal
        text(midPoint(1) ,midPoint(2) ,string(side_id(locId)), 'Color', 'k')     
    end
end
	


