classdef RevisedNavierStokes < NavierStokes
    
    properties
        alpha;
    end
    
    methods
        %% CONSTRUCTOR
        %------------------------------------------------------------------
        function this = RevisedNavierStokes(meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag)
            
            this = this.initialize(meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag);

        end 
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, N, M_alpha, c)
            %--------------------------------------------------------------
            Nodes_v = this.V.Nodes;
            Nodes_p  = this.P.Nodes;
            %----
            A       = this.ni * this.LinSys.A;
            M       = c  * this.LinSys.M;
            B1      = this.LinSys.B1/this.rho;
            B2      = this.LinSys.B2/this.rho;
            M_alpha = M_alpha/this.rho;
            %----
            SYSMAT=[A+M+N+M_alpha          , sparse(Nodes_v,Nodes_v), B1';
                    sparse(Nodes_v,Nodes_v), A+M+N+M_alpha          , B2';
                    B1                     , B2                     , sparse(Nodes_p,Nodes_p)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------     
        %% SOLVER
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p, check_flag] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % SOLVER OF NAVIER STOKES EQUATIONS
            %--------------------------------------------------------------
            toll = 1e-2;
            c = 1/Dt;
            %------
            u1_r = u1_0;
            u2_r = u2_0;
            %------
            % Collect matrices
            M         = this.LinSys.M;
            M_alpha   = BuildMalpha(this);
            rhs_base  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %------
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*this.V.Nodes,1) = rhs_base(1:2*this.V.Nodes) + [M * u1_0; M * u2_0] * c;
            %-----
            scarto = toll + 1;
            scarto_old = scarto + 1;
            it = 0;
            check_flag = 1;
           %---------
            % loop for stabilization
            while scarto > toll 
                %--------------
                N  = BuildN(this, u1_r, u2_r);
                SYSMAT       = stiffBuild(this, N, M_alpha, c);
                %-----
                [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
                sol          = SYSMAT\rhs;
                u1_new       = sol(1:this.V.Nodes); 
                u2_new       = sol(this.V.Nodes+1:this.V.Nodes*2); 
                scarto       = sqrt(this.evalErr(u1_new,u1_r, this.V)^2 + this.evalErr(u2_new,u2_r, this.V)^2)/2;
                u1_r = u1_new; u2_r = u2_new;
                it = it+1;
                %-------
                if (scarto_old < scarto/1.2 && it >= 10) || it >20
                    check_flag = 0;
                    warning('Instability for convective term. Need to decrease the time interval or increase the numerical diffusion');
                    warning("Scarto = " + num2str(scarto));
                    break;
                end
                scarto_old = scarto;
                %-------
            end
            %-----------
            % Update Results
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %----------------------------------------------------------------------
    %%% PRIVATE METHODS
    %----------------------------------------------------------------------
    methods(Access = private)
        %% BUILD THE STIFFNESS MATRIX
        function [M, M_alpha, A,N] = BuildM_Malpha_A_N(this)
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse   = zeros(Nelem_v*9,1);
            j_sparse   = zeros(Nelem_v*9,1);
            H_val      = zeros(Nelem_v*9,1);
            M_val      = zeros(Nelem_v*9,1);
            Malpha_val = zeros(Nelem_v*9,1);
            N_val      = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                verteces = triang_v(iel,:);
                beta1 = this.u1_r(verteces,1); beta2 = this.u2_r (verteces,1);
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=verteces(iloc);
                    beta1_mean =[2*beta1(iloc)            + beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3));
                                 2*beta2(iloc)            + beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3))];
                    beta2_mean =[2*beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3));
                                 2*beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3))];
                    beta3_mean =[2*beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3)) + beta1(mod_n(iloc+4,3));
                                 2*beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3)) + beta2(mod_n(iloc+4,3))];
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=verteces(jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        %-----------------
                        % BUILD DIFF MATRIX
                        H_val(it)=(Bloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                   Cloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                        %-----------------
                        % BUILD MASS MATRIX
                        if iloc==jloc
                             M_val(it)=Area_v(iel)/6;
                         else
                             M_val(it)=Area_v(iel)/12;
                        end
                        %--------------------------------------------------
                        % BUILD M_alpha MATRIX
                        %%% int_\Omega { alpha(x) phi_i phy_j} with
                        %%% gaussian quadrature of order 2
                        % sum_i { alpha(b_i) phi_i(b_i) phi_j(b_i) }
                        if iloc==jloc
                             Malpha_val(it)= 1/4 * (2*this.alpha(iglob) + ...
                                               this.alpha(verteces(mod_n(iloc+1,3)))...
                                             + this.alpha(verteces(mod_n(iloc+2,3))))/2 * ...
                                               Area_v(iel) / 3;
                         else
                             Malpha_val(it) = 1/4 * (this.alpha(iglob) ... 
                                              + this.alpha(jglob))/2 *...
                                                Area_v(iel) / 3;
                        end
                        %--------------------------------------------------
                        % BUILD N MATRIX + SUPG
                        N_valval = 1/4*(beta1_mean' * [Bloc_v(iel,jloc); Cloc_v(iel,jloc)]) ...
                                          * Area_v(iel)/3;

                        if norm(beta1_mean) > 1e-3
                        S = this.tau/this.mu*this.h(iel)/2 / norm(beta1_mean) *...
                                [Bloc_v(iel,jloc), Cloc_v(iel,jloc)] * [beta1_mean, beta2_mean, beta3_mean] * ...
                                [beta1_mean'; beta2_mean'; beta3_mean'] * [Bloc_v(iel,iloc); Cloc_v(iel,iloc)] * ...
                                 Area_v(iel)/3;
                        else
                            S = 0;
                        end

                        N_val(it) = N_valval + S;
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            A       = sparse(i_sparse,j_sparse,H_val);
            M       = sparse(i_sparse,j_sparse,M_val);
            M_alpha = sparse(i_sparse,j_sparse,Malpha_val);
            N       = sparse(i_sparse,j_sparse,N_val);
            %--------------------------------------------------------------
        end
    end
end

