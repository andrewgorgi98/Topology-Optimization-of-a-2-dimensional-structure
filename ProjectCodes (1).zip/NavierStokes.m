classdef NavierStokes < Stokes
    %NAVIERSTOKES Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        ni;
        rho;
        h;
        tau;
    end
    
    methods
        function this = NavierStokes()
            
        end

        function this = initialize(this,meshdir,nfig, mu, rho, f_1, f_2, g, tau, flag_mesh)
            this = initialize@Stokes(this,meshdir,nfig, mu, f_1, f_2, g, flag_mesh);
            this.ni   = mu/rho;
            this.rho  = rho;
            this.tau = tau;
            %-----------
            h_temp = zeros(this.V.Nelem,1); % max length of each triangle
            V = zeros(3,2);     % coordinates of triangle vertices
            d = zeros(3,1);     % distances between each vrteces couple of the triangle
            triang = this.V.triang;
            this.h = sparse(this.V.Nelem);
            for iel=1:this.V.Nelem
                for iloc=1:3
                    xglob = triang(iel,iloc);
                    V(iloc,:) = this.V.coord(xglob);
                end
                for i=1:2
                    d(i)=norm(V(i,:)-V(i+1,:));
                end
                d(3)=norm(V(1,:)-V(3,:));
                h_temp(iel)=max(d);
            end
            this.h = h_temp;
            %-----------
        end
        %% BUILD THE STIFFNESS MATRIX
        
        function SYSMAT = stiffBuild(this, N, c)
            %--------------------------------------------------------------
            Nodes_v = this.V.Nodes;
            Nodes_p  = this.P.Nodes;
            %----
            A  = this.ni * this.LinSys.A;
            M  = c  * this.LinSys.M;
            B1 = this.LinSys.B1/this.rho;
            B2 = this.LinSys.B2/this.rho;
            %----
            SYSMAT=[A+M+N                  , sparse(Nodes_v,Nodes_v), B1';
                    sparse(Nodes_v,Nodes_v), A+M+N                  , B2';
                    B1                     , B2                     , sparse(Nodes_p,Nodes_p)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        %%% DIRECT STATIONARY SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = DirectStatSolver(this, flag)
            %--------------------------------------------------------------
            Dt = 1e4;
            [u1_0, u2_0] = this.zeroInitCond();
            [uh1, uh2, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% STEADY STATE TROUGHT TIME ITERATIONS
        %------------------------------------------------------------------
        function [uh1, uh2, p] = StatSolver(this, flag, u1_0, u2_0)
            if nargin == 2
                [u1_0, u2_0] = this.zeroInitCond();
            end
            toll   = 1e-2;
            scarto = toll + 1;
            Dt     = 0.05;
            time   = 0;
            while scarto > toll
                [u1_0_new, u2_0_new, p, check_flag] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                scarto = sqrt(this.evalErr(u1_0_new,u1_0,this.V)^2 + this.evalErr(u2_0_new,u2_0,this.V)^2)/2;
                u1_0 = u1_0_new;
                u2_0 = u2_0_new;
                time = time + Dt;
                if check_flag ~= 1
                    Dt = Dt/2;
                    continue;
                end
                if time > Dt * 300
                    warning('Couldn''t find steady state, instability or too high time interval');
                    warning("Scarto = " + num2str(scarto));
                    break;
                end
            end
            if scarto < toll
                fprintf('\nSteady state achieved in less than %4.2f seconds\n', time);
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% TIME DEPENDENT SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = TimeDepSolver(this, u1_0, u2_0, Dt, T_end, flag)
            time = 0;
            while time < T_end
                [u1_trial, u2_trial, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                if check_flag ~= 1
                    Dt = Dt/2;
                    continue;
                end
                u1_0 = u1_trial;
                u2_0 = u2_trial;
                time = time + Dt;
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p, check_flag] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % SOLVER OF NAVIER STOKES EQUATIONS
            %--------------------------------------------------------------
            toll = 1e-2;
            c = 1/Dt;
            %------
            u1_r = u1_0;
            u2_r = u2_0;
            %------
            % Collect matrices
            M  = this.LinSys.M;
            rhs_base  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %------
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*this.V.Nodes,1) = rhs_base(1:2*this.V.Nodes) + [M * u1_0; M * u2_0] * c;
            %-----
            scarto = toll + 1;
            scarto_old = scarto + 1;
            it = 0;
            check_flag = 1;
           %---------
            % loop for stabilization
            while scarto > toll 
                %--------------
                N  = BuildN(this, u1_r, u2_r);
                SYSMAT       = stiffBuild(this, N, c);
                %-----
                [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
                sol          = SYSMAT\rhs;
                u1_new       = sol(1:this.V.Nodes); 
                u2_new       = sol(this.V.Nodes+1:this.V.Nodes*2); 
                scarto       = sqrt(this.evalErr(u1_new,u1_r)^2 + this.evalErr(u2_new,u2_r)^2)/2;
                u1_r = u1_new; u2_r = u2_new;
                it = it+1;
                %-------
                if scarto_old < scarto/1.2 || it >= 20
                    check_flag = 0;
                    warning('Instability for convective term. Need to decrease the time interval or increase the numerical diffusion');
                    warning("Scarto = " + num2str(scarto));
                    break;
                end
                scarto_old = scarto;
                %-------
            end
            %-----------
            % Update Results
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    methods(Access = protected)
        %-------------
        function N = BuildN(this, u1_r, u2_r)
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            N_val    = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                verteces = triang_v(iel,:);
                beta1 = u1_r(verteces,1); beta2 = u2_r (verteces,1);
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=verteces(iloc);
                    beta1_mean =[2*beta1(iloc)            + beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3));
                                 2*beta2(iloc)            + beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3))];
                    beta2_mean =[2*beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3));
                                 2*beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3))];
                    beta3_mean =[2*beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3)) + beta1(mod_n(iloc+4,3));
                                 2*beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3)) + beta2(mod_n(iloc+4,3))];
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=verteces(jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        %--------------------------------------------------
                        N_valval = 1/4*(beta1_mean' * [Bloc_v(iel,jloc); Cloc_v(iel,jloc)]) ...
                                          * Area_v(iel)/3;

                        if norm(beta1_mean) > 1e-3
                        S = this.tau/this.mu*this.h(iel)/2 / norm(beta1_mean) *...
                                [Bloc_v(iel,jloc), Cloc_v(iel,jloc)] * [beta1_mean, beta2_mean, beta3_mean] * ...
                                [beta1_mean'; beta2_mean'; beta3_mean'] * [Bloc_v(iel,iloc); Cloc_v(iel,iloc)] * ...
                                 Area_v(iel)/3;
                        else
                            S = 0;
                        end

                        N_val(it) = N_valval + S;
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            N = sparse(i_sparse,j_sparse,N_val);
            %--------------------------------------------------------------
        end
        %-------------
    end
    methods(Access = private)
        %% BUILD THE STIFFNESS MATRIX
        function [M,A,N] = BuildM_A_N(this)
            
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            H_val    = zeros(Nelem_v*9,1);
            M_val    = zeros(Nelem_v*9,1);
            N_val    = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                verteces = triang_v(iel,:);
                beta1 = this.u1_r(verteces,1); beta2 = this.u2_r (verteces,1);
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=verteces(iloc);
                    beta1_mean =[2*beta1(iloc)            + beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3));
                                 2*beta2(iloc)            + beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3))];
                    beta2_mean =[2*beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3));
                                 2*beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3))];
                    beta3_mean =[2*beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3)) + beta1(mod_n(iloc+4,3));
                                 2*beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3)) + beta2(mod_n(iloc+4,3))];
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=verteces(jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        %-----------------
                        % BUILD DIFF MATRIX
                        H_val(it)=(Bloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                   Cloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                        %-----------------
                        % BUILD MASS MATRIX
                        if iloc==jloc
                             M_val(it)=Area_v(iel)/6;
                         else
                             M_val(it)=Area_v(iel)/12;
                        end
                        %--------------------------------------------------
                        % BUILD M_alpha MATRIX
                        N_valval = 1/4*(beta1_mean' * [Bloc_v(iel,jloc); Cloc_v(iel,jloc)]) ...
                                          * Area_v(iel)/3;

                        if norm(beta1_mean) > 1e-3
                        S = this.tau/this.mu*this.h(iel)/2 / norm(beta1_mean) *...
                                [Bloc_v(iel,jloc), Cloc_v(iel,jloc)] * [beta1_mean, beta2_mean, beta3_mean] * ...
                                [beta1_mean'; beta2_mean'; beta3_mean'] * [Bloc_v(iel,iloc); Cloc_v(iel,iloc)] * ...
                                 Area_v(iel)/3;
                        else
                            S = 0;
                        end

                        N_val(it) = N_valval + S;
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            A = sparse(i_sparse,j_sparse,H_val);
            M = sparse(i_sparse,j_sparse,M_val);
            N = sparse(i_sparse,j_sparse,N_val);
            %--------------------------------------------------------------
        end
    end
end

