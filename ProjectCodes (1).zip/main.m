%%% Main script for topology optimization of Stokes problem in a channel
clear; close all; clc;

% Define the 2D mesh and equation BC's and coefficients
meshdir='mesh_COMSOL\lastra_rect_fine\lastra_rect_fine.txt';
nfig   = 1;

% flag_functional = 1 for min (\alpha ||u||^2)
%                   2 for min (\alpha ||u||^2 + 1/2* \mu ||grad(u)||^2)
%-------------------
flag_functional = 2;
inlet_id        = [1];
outlet_id       = [8];
%--------------------------------------------------------------------------
% SET PARAMETERS
%--------------------------------------------------------------------------
UseNStokes = true;

flag      = 0; % flag=1 to see the mesh
flag_BC   = 0; % BC: 0 for FAST penalty method
               %   : 1 for ACCURATE lifting function method
               
seeEdgeID = true;

V_r       = 0.8; 
V_0       = 2.9;  %%% !!!!!!!!!!!! TO BE SET WITH GEOMETRY !!!!!!!!
alpha_min = 0;
alpha_max = 1e3;
q         = 1;
mu        = 1; 
rho       = 1;
f_1       = @(x,y) 0;
f_2       = @(x,y) 0;
g         = @(x,y) 0;
tau       = 0.00001;

V_in = @(x,y) 4*[(y)*(1.0-y); 0];
%--------------------------------------------------------------------------
% INITIALIZE SOLVER
%--------------------------------------------------------------------------
tic;
disp('INITIALIZE SOLVER FOR MASTER PROBLEM');
disp('-----------------------------------'); 
disp('-----------------------------------');

if UseNStokes
    NStokes = RevisedNavierStokes(meshdir, nfig, mu, rho, f_1, f_2, g, tau, flag);
else
    NStokes = RevisedStokes(meshdir,nfig, mu, f_1, f_2, g, flag);
end

if seeEdgeID
    figure(2)
    hold on;
    % TESTING PLOT SIDES
    PlotSideNodes(NStokes.X_limits, NStokes.Y_limits, NStokes.V.coord, ...
        NStokes.Bound.Nodes, NStokes.Bound.NodesId, 1:max(NStokes.Bound.EdgesId));
    drawnow;
    hold off;
end

limits = [NStokes.X_limits, NStokes.Y_limits];
nfig = nfig+1;

toc;
%--------------------------------------------------------------------------
% INITIALIZE PARAMETER GAMMA
%--------------------------------------------------------------------------
gamma = 1.0 * ones(NStokes.V.Nodes,1);
%--------------------------------------------------------------------------
% SET BC
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('SET BC');
disp('-----------------------------------'); disp('-----------------------------------');




% INLET BC
%-------------------------------
% Edge Index imported from COMSOL
for i = 1:length(inlet_id)
    NStokes = NStokes.setEdgeDirBC(inlet_id(i), V_in); 
end


% WALL BC
%-------------------------------
for i = 1 : NStokes.Bound.NBound
    if ismember(i,inlet_id) || ismember(i,outlet_id)
        continue
    end
    NStokes = NStokes.setEdgeDirBC(i, @(x,y) [0,0]); 
end


% DO NOTHING OUTFLOW BC
%-------------------------------
for i = 1:length(outlet_id)
    NStokes = NStokes.setEdgeNeuBC(outlet_id(i), [0,0]);
end
toc;
%--------------------------------------------------------------------------
% PREPRO
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('PREPRO');
disp('-----------------------------------'); disp('-----------------------------------');
NStokes = NStokes.prepro;
toc;
%--------------------------------------------------------------------------
% INITIALIZE ADJOINT AND MMA SOLVER
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('ADJOINT SYSTEM AND MMA INITIALIZATION');
disp('-----------------------------------'); disp('-----------------------------------');
% initialize Adjoint
if UseNStokes
    Adjoint = ADJOINT_NS(NStokes, mu, rho, flag_functional);
else
    Adjoint = ADJOINT(NStokes, mu, rho, flag_functional);
end
% initialize MMA
Optimizer = MMA(q, V_r, V_0, alpha_min, alpha_max, NStokes.V, mu, flag_functional);
toc;
%--------------------------------------------------------------------------
loop = 0;
toll = 1e-3;
change = toll + 1;
[u1_0, u2_0] = NStokes.zeroInitCond();

%%  LAUNCH SOLVER
while (change > toll)
%--------------------------------------------------------------------------
% UPDATE PARAMETER GAMMA
%--------------------------------------------------------------------------
alpha = alpha_min + (alpha_max - alpha_min).*q.*(1-gamma)./(q+gamma);
NStokes.alpha = alpha;
%--------------------------------------------------------------------------
% SOLVE
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('SOLVE MASTER PROBLEM');
disp('-----------------------------------');
disp('-----------------------------------');
[uh1, uh2, ph] = NStokes.StatSolver(flag_BC, u1_0, u2_0);
% u1_0 = uh1; u2_0 = uh2;
toc;

%----------------------------------------
% UPDATE STREAMLINE AND DESIGN PLOTS
%----------------------------------------
figure(3)
for iedge = 1:size(NStokes.Bound.Edges,1)
    p1 = NStokes.V.coord(NStokes.Bound.Edges(iedge,1),:);
    p2 = NStokes.V.coord(NStokes.Bound.Edges(iedge,2),:);
    plot([p1(1), p2(1)], [p1(2), p2(2)], 'k-');
    hold on;
end

[x,y] = meshgrid(NStokes.X_limits(1):0.1:NStokes.X_limits(2), ...
                 NStokes.Y_limits(1):0.1:NStokes.Y_limits(2));
u = zeros(size(x)); v = zeros(size(x));
for i = 1:numel(x)
    [u(i), v(i)]= NStokes.getApproxValue_v([x(i);y(i)],uh1,uh2);
    if norm([u(i), v(i)]) < 1e-2
        u(i) = 0;
        v(i) = 0;
    end
end
quiver(x,y,u,v, 'Color', 'b');
% streamslice(x,y,u,v);
hold off;

%--------------------------------------------------------------------------
% BUILD ADJOINT SYSTEM
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('Build Adjoint system');
disp('-----------------------------------');
disp('-----------------------------------');
Adjoint = Adjoint.Update(uh1,uh2,ph,alpha);

switch flag_functional
    case 1
        Adjoint.f_1    = -2.*alpha.*uh1/rho;
        Adjoint.f_2    = -2.*alpha.*uh2/rho;
        Adjoint.g      = zeros(Adjoint.P.Nodes);
    case 2
        Adjoint.f_1    = -2*alpha.*uh1/rho;
        Adjoint.f_2    = -2*alpha.*uh2/rho;
        Adjoint.g      = zeros(Adjoint.P.Nodes);
    case 3
        Adjoint.f_1    = zeros(Adjoint.V.Nodes);
        Adjoint.f_2    = zeros(Adjoint.V.Nodes);
        Adjoint.g      = zeros(Adjoint.P.Nodes);
end

Adjoint = Adjoint.clearBC();
toc;

%--------------------------------------------------------------------------
% SET ADJOINT BC
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('SET ADJOINT BC');
disp('-----------------------------------'); 
disp('-----------------------------------');



for i = 1:NStokes.Bound.NBound
    if ismember(i,outlet_id)
        continue
    end
    Adjoint = Adjoint.setEdgeDirBC(i,@(x,y)[0,0]);
end
%-------------------------------
for i = 1:length(outlet_id)
    Adjoint = Adjoint.setEdgeNeuBC(outlet_id(i));
end

toc;
%--------------------------------------------------------------------------
% SOLVE
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('ADJOINT SOLVER');
disp('-----------------------------------'); 
disp('-----------------------------------')
Adjoint = Adjoint.Prepro;
[ua1, ua2, pa] = Adjoint.DirectStatSolver(flag_BC);
toc;

%--------------------------------------------------------------------------
% CALL MMA METHOD
%--------------------------------------------------------------------------
tic;
disp('-----------------------------------')
disp('UPDATE AND SOLVE MMA');
disp('-----------------------------------'); 
disp('-----------------------------------')
Optimizer = Optimizer.Update(uh1, uh2, ua1, ua2);
[gamma_new, f0val, Vol] = Optimizer.solve(gamma);
toc;

% PRINT RESULTS
change = Solver.evalErr(gamma, gamma_new, NStokes.V);
loop  = loop + 1;
disp([' It.: ' sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',f0val) ...
      ' Vol.: ' sprintf('%6.3f',Vol) ...
      ' ch.: ' sprintf('%6.3f',change )]);
  
% % PLOT DENSITIES
figure(4)
x=NStokes.V.coord(:,1); y=NStokes.V.coord(:,2);
M=delaunay(x,y);
cd triplot
tricontf(x,y,M,gamma_new,10);
colormap(gray)
gamma = gamma_new;
axis(limits);
cd ..

end

%% PRINT FINAL RESULTS
NStokes.PrintRes(uh1,uh2,ph,5);
