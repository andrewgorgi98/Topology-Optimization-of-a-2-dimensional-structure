classdef Stokes < Solver
    %   SolverStokesP1P2 Solver of Stokes problem with a P1-iso-P2 approach
    %   Find nodal values of solution (u,p) to 
    %   u_t - /mu*/div /grad(u) + /grad(p) = f
    %                           div(u) = g 
    %----------------------------------------------------------------------
    properties
        currSol;
        mu;
        f_1;
        f_2;
        g;
        connectivity;
    end
    %----------------------------------------------------------------------
    methods (Access = public)
        %------------------------------------------------------------------
        % *CONSTRUCTOR*
        function this = SolverStokesP1P2()
            
        end
        %------------------------------------------------------------------
        function  this = copy(this, solver)
            this = copy@Solver(this,solver);
            this.connectivity  = solver.connectivity;
        end
        %------------------------------------------------------------------
        % *DEFINE THE MESH*
        function this = initialize(this,meshdir,nfig, mu, f_1, f_2, g, flag_mesh)
            % meshdir: name of the folder which contains the mesh
            % nfig: number of the first free figure panel
            
            [coord, triang, bound_edges, bound_edges_id] = this.readFromComsolMesh(meshdir);

            N_bound = max(bound_edges_id);
            N = length(bound_edges);
            BoundNodes = zeros(N,1);
            BoundNodesId = zeros(N,1); 
            count = 0;
            for i=1:N
                for side = 1:N_bound
                    if bound_edges_id(i) == side
                        for jloc=1:2
                            jglob = bound_edges(i,jloc);
                            if ~ismember(jglob, BoundNodes)
                                count = count + 1;
                                BoundNodes(count) = jglob;
                                BoundNodesId(count) = bound_edges_id(i);
                            end
                        end
                    end
                end
            end

            %--------------------------------------------------------------
            Nelem_p                   = length(triang(:,1));
            Nodes_p                   = size(coord,1);
            coord_v                   = zeros(Nodes_p+Nelem_p*3,2);
            coord_v(1:Nodes_p,:)      = coord;
            triang_v                  = zeros(Nelem_p*4,3);
            this.connectivity         = zeros(Nelem_p,4);
            count                     = Nodes_p+1;
            %--------------------------
            BoundEdges_v              = zeros(length(BoundNodes)*2,2);
            BoundEdges_v_id           = zeros(length(BoundEdges_v),1);
            BoundTriang_v             = zeros(length(BoundEdges_v),3);
            BoundExtNormal            = zeros(length(BoundEdges_v),2);
            
            BCcount                   = length(BoundNodes)+1;
            EdgeCount                 = 0;
            IsCreated = zeros(Nodes_p,Nodes_p); % check if arc iglob-jglob has already been selected
                                                % and stores entry index
            IsBC      = zeros(Nodes_p,1);
            IsBC(BoundNodes) = 1;
            id = zeros(4,1);
            %----------------
            for iel=1:Nelem_p
                verteces = triang(iel,:);
                vcs      = coord(verteces,:);
                iglob       = zeros(1,3);
                %%% id(1) = middle of arc 1-2
                %%% id(2) = middle of arc 2-3
                %%% id(3) = middle of arc 3-1
                for iloc=1:3
                    iarc = verteces(iloc); jarc = verteces(mod_n(iloc+1,3));
                    flag = IsCreated(iarc,jarc);
                    %---------------------------
                    if flag == 0
                        IsCreated(iarc,jarc) = count;
                        IsCreated(jarc,iarc) = count;
                        newpoint = (vcs(iloc,:)+ vcs(mod_n(iloc+1,3),:))/2;
                        coord_v(count,:) = newpoint;
                        iglob(iloc)      = count;
                        %-------------
                        %%% BC 
                        if IsBC(iarc) && IsBC(jarc)
                            %---------
                            thirdNode = verteces(mod_n(iloc + 2,3));
                            normal    = this.extNormal(coord(iarc,:), coord(jarc,:), coord(thirdNode,:));
                            %---------
                            tempEdgeId = findEdgeId(iarc, jarc, bound_edges, bound_edges_id);
                            BoundNodes(BCcount)   = count; 
                            BoundNodesId(BCcount) = tempEdgeId;
                            %---------
                            EdgeCount = EdgeCount + 1;
                            BoundEdges_v(EdgeCount,:)    = [iarc, count];
                            BoundEdges_v_id(EdgeCount,:) = tempEdgeId;
                            BoundTriang_v(EdgeCount,:)   = [id(4)+iloc, 1, 2];
                            BoundExtNormal(EdgeCount,:)  = normal;
                            %----
                            EdgeCount = EdgeCount + 1;
                            BoundEdges_v(EdgeCount,:)    = [count, jarc];
                            BoundEdges_v_id(EdgeCount,:) = tempEdgeId;
                            BoundTriang_v(EdgeCount,:)   = [id(4)+mod_n(iloc+1,3), 1, 3];
                            BoundExtNormal(EdgeCount,:)  = normal;
                            %---------
                            BCcount = BCcount+1;
                       end
                        count = count + 1;
                    else
                        iglob(iloc) = flag;
                    end
                end %iloc
                %----------------------------------------------------------
                % update triang_v
                id = (4*(iel-1))*ones(1,4) + (1:4);
                triang_v(id(1),:) = [verteces(1), iglob(1), iglob(3)];
                triang_v(id(2),:) = [verteces(2), iglob(2), iglob(1)];
                triang_v(id(3),:) = [verteces(3), iglob(3), iglob(2)];
                triang_v(id(4),:) = [iglob(1)   , iglob(2), iglob(3)];
                % update connectivity
                this.connectivity(iel,:) = id;
                %----------------------------------------------------------
            end 
            coord_v = coord_v(1:count-1,:);
            this.Bound.EdgesLength = zeros(size(BoundEdges_v,1),1);
            for iedge = 1 : size(BoundEdges_v,1)
                iglob = BoundEdges_v(iedge,1);
                jglob = BoundEdges_v(iedge,2);
                this.Bound.EdgesLength(iedge) = norm(coord_v(iglob,:) - coord_v(jglob,:));
            end
            %--------------------------------------------------------------
            % set domain info
            this.X_limits = [min(coord(:,1)),max(coord(:,1))];
            this.Y_limits = [min(coord(:,2)),max(coord(:,2))];

            this.Bound.Nodes     = BoundNodes;
            this.Bound.NodesId   = BoundNodesId;
            this.Bound.Edges     = BoundEdges_v;
            this.Bound.Triang    = BoundTriang_v;
            this.Bound.Check(1:size(coord_v,1)) = "none";
            this.Bound.BCid      = sparse(zeros(size(coord_v,1),1));
            this.Bound.EdgesId   = BoundEdges_v_id;
            this.Bound.NBound    = N_bound;
            this.Bound.ExtNormal = BoundExtNormal;
            %--------------------------------------------------------------
            % set P
            this.P.triang = triang;
            this.P.coord  = coord;
            this.P.Nodes  = Nodes_p;
            this.P.Nelem  = Nelem_p; 
            %--------------
            % set V
            this.V.coord  = coord_v;
            this.V.triang = triang_v; %delaunay(coord_v(:,1),coord_v(:,2));
            this.V.Nelem  = size(this.V.triang,1);
            this.V.Nodes  = size(this.V.coord,1);
            this.V.DirNod = [];
            this.V.DirVal = [];
            this.V.NDir   = [];
            
            this.V.NeuNod = [];
            this.V.NeuVal = [];
            this.V.NNeu   = [];
            
            
            %--------------------------------------------------------------
            %%% set coefficients    
            this.mu = mu;
            this.f_1 = f_1; %@(x,y) c.*u_1(x,y)-4*mu*pi^2.*sin(2*pi.*y).*(2*cos(2*pi.*x)-1)+4*pi^2.*sin(2*pi.*x);
            this.f_2 = f_2; %c.*u_2(x,y)+4*mu*pi^2.*sin(2*pi.*x).*(2*cos(2*pi.*y)-1)-4*pi^2.*sin(2*pi.*y);
            this.g   = g;
            %--------------------------------------------------------------
            if flag_mesh
                figure(nfig)
                trimesh(this.V.triang,this.V.coord(:,1),this.V.coord(:,2),'Color','k')
                hold on 
                trimesh(this.P.triang,this.P.coord(:,1),this.P.coord(:,2),'Color','r','LineWidth',1.1)
            end
            %--------------------------------------------------------------
            %Whole Domain NO-SLIP
            for i = 1:N_bound
            this = this.setEdgeDirBC(i,@(x,y)[0,0]);
            end
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        %------------------------------------------------------------------
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            A  = this.mu * this.LinSys.A;
            M  = c  * this.LinSys.M;
            B1 = this.LinSys.B1;
            B2 = this.LinSys.B2;

            SYSMAT=[A+M                              ,sparse(this.V.Nodes,this.V.Nodes), B1';
                    sparse(this.V.Nodes,this.V.Nodes), A+M                             , B2';
                    B1                               , B2                              , sparse(this.P.Nodes,this.P.Nodes)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% PREPRO, PREPARE THE SOLVER 
        %------------------------------------------------------------------
        function this = prepro(this)
            %--------------------------------------------------------------
            % compute local basis
            [this.V.Bloc, this.V.Cloc, this.V.Area] = ...
                                     this.LocalBasis(this.V.Nelem,this.V.triang,this.V.coord);
            [this.P.Bloc, this.P.Cloc, this.P.Area] = ...
                                     this.LocalBasis(this.P.Nelem,this.P.triang,this.P.coord);
            %----------
            % Compute Matrices
            
            [M, A, HT1, HT2]   = BuildMass_Diff(this);
            [B1, B2] = Build_b(this);
            [rhs, P_bc] = forcing(this);
            this.LinSys.M      = M;
            this.LinSys.A      = A;
            this.LinSys.HT1    = HT1;
            this.LinSys.HT2    = HT2;
            this.LinSys.B1     = B1;
            this.LinSys.B2     = B2;
            this.LinSys.rhs    = rhs;
            this.LinSys.P_bc   = P_bc;
        end
        %------------------------------------------------------------------
        %% SOLVER
        %------------------------------------------------------------------
        %%% DIRECT STATIONARY SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = DirectStatSolver(this, flag)
            % SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            %-------
            SYSMAT   = stiffBuild(this, 0);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% TIME DEPENDENT SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = TimeDepSolver(this, u1_0, u2_0, Dt, T_end, flag)
            time = 0;
            while time < T_end
                [u1_0, u2_0, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                time = time + Dt;
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% STEADY STATE TROUGHT TIME ITERATIONS
        %------------------------------------------------------------------
        function [uh1, uh2, p] = StatSolver(this, flag, u1_0, u2_0)
            if nargin == 2
                [u1_0, u2_0] = this.zeroInitCond();
            end
            toll   = 1e-2;
            scarto = toll + 1;
            time   = 0;
            Dt = 0.1;
            while scarto > toll
                [u1_0_new, u2_0_new, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag);
                scarto = sqrt(this.evalErr(u1_0_new,u1_0,this.V)^2 + this.evalErr(u2_0_new,u2_0,this.V)^2)/2;
                u1_0 = u1_0_new;
                u2_0 = u2_0_new;
                time = time + Dt;
                if time > Dt * 300
                    warning('Couldn''t find steady state, instability or too high time interval');
                    break;
                end
            end
            if scarto < toll
                fprintf('\nSteady state achieved in less than %4.2 seconds\n', time);
            end
            uh1 = u1_0; 
            uh2 = u2_0; 
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %%% SINGLE ITERATION SOLVER
        %------------------------------------------------------------------
        function [uh1, uh2, p] = OneStepSolver(this, u1_0, u2_0, Dt, flag)
            % TIME DEPENDENT SOLVER OF STOKES EQUATIONS
            %--------------------------------------------------------------
            rhs_base  = this.LinSys.rhs;
            P_bc = this.LinSys.P_bc;
            M    = this.LinSys.M;
            % Correct the rhs according to implicit Euler formulation
            rhs_1 = rhs_base;
            rhs_1(1:2*this.V.Nodes,1) = rhs_base(1:2*this.V.Nodes) + [M * u1_0; M * u2_0]/Dt;
            %-------
            SYSMAT   = stiffBuild(this, 1/Dt);
            [SYSMAT,rhs] = imposeBC(this,P_bc,SYSMAT,rhs_1,flag);
            sol = SYSMAT\rhs;
            uh1 = sol(1:this.V.Nodes); 
            uh2 = sol(this.V.Nodes+1:this.V.Nodes*2); 
            p   = sol(this.V.Nodes*2+1:end);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    % PROTECTED METHODS
    %%%--------------------------------------------------------------------
    %%%--------------------------------------------------------------------
    methods (Access = protected)
        %% IMPOSE BOUNDARY CONDITIONS
        function [stiffMat,rhs] = imposeBC(this,P_bc,stiffMat,rhs,flag)
            %--------------------------------------------------------------
            % impose Dirichle BCs
            % flag: 0 => penalty method;
            %     : 1 => Lifting function;
            if nargin < 5
                flag = 0;
            end
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            NDir_v   = this.V.NDir;
            DirNod_v = this.V.DirNod;
            DirVal_v = this.V.DirVal;
            
            NNeu     = this.V.NNeu;
            NeuNod  = this.V.NeuNod;
            NeuVal   = this.V.NeuVal;
            %-----------------------
            %%% DIRICHLET
            %--------------------------------------------------------------
            switch flag 
                %----------------------------------------------------------
                case 0
                    %------------------------------------------------------
                    penalty=1e10;
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=penalty;
                            rhs((k-1)*Nodes_v+iglob)=penalty*DirVal_v(idir,k);
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                case 1
                    %------------------------------------------------------
                    for k=1:2
                        %--------------------------------------------------
                        for idir=1:NDir_v
                            %----------------------------------------------
                            iglob=DirNod_v(idir);   
                            stiffMat((k-1)*Nodes_v+iglob,:)=0; 
                            rhs=rhs-DirVal_v(idir,k)*stiffMat(:,(k-1)*Nodes_v+iglob); 
                            rhs((k-1)*Nodes_v+iglob)=DirVal_v(idir, k);
                            stiffMat(:,(k-1)*Nodes_v+iglob)=0;
                            stiffMat((k-1)*Nodes_v+iglob,(k-1)*Nodes_v+iglob)=1;
                            %----------------------------------------------
                        end
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
            end
            %------------------------
            %%%% NEUMANN
            for k = 1:2
                for ineu = 1 :NNeu
                    iglob = NeuNod(ineu);
                    rhs((k-1)*Nodes_v+iglob) = rhs((k-1)*Nodes_v+iglob) + NeuVal(ineu,k);
                end
            end
            %%% ZERO MEAN PRESSURE CONDITION IF NO NEUMANN BC
            %--------------------------------------------------------------
            if sum(this.Bound.Check == "Neu") == 0
            stiffMat(2*Nodes_v+this.P.Nodes+1,1:2*Nodes_v)=0;
            stiffMat(2*Nodes_v+this.P.Nodes+1,2*Nodes_v+1:end)=P_bc;
            rhs(2*Nodes_v+this.P.Nodes+1)=0;
            stiffMat(2*Nodes_v+iglob,1:2*Nodes_v)=0;
            stiffMat(2*Nodes_v+iglob,2*Nodes_v+1:end)=P_bc;
            rhs(2*Nodes_v+iglob)=0;

            stiffMat(iglob,1:2*Nodes_v)=0;
            stiffMat(iglob,iglob)=1;
            rhs(iglob)=0;
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% FORCING
        function [rhs, P_bc] = forcing(this)
            % using the trapezoidal rule for evaluating the integral
            % (it is exact on linear functions)
            % has a convergence error compatible with linear P1 FEM
            % Trapezoidal is used here exploiting the fact that
            % in one of the nodes the phi is zero!!! (only 1 term)
            %--------------------------------------------------------------
            Nodes_v  = this.V.Nodes;
            coord_v  = this.V.coord;
            triang_v = this.V.triang;
            Area_v   = this.V.Area;
            triang_p = this.P.triang;
            Area_p   = this.P.Area;
            rhs      = zeros(2*Nodes_v+this.P.Nodes,1);
            P_bc     = zeros(this.P.Nodes,1);
            %--------------------------------------------------------------
            for iel=1:this.V.Nelem
                %----------------------------------------------------------
                for iloc=1:3
                    iglob=triang_v(iel,iloc);
                    x=coord_v(iglob,1); y=coord_v(iglob,2);
                    rhs(iglob)=rhs(iglob)+...
                        this.f_1(x,y)/3*Area_v(iel);
                    rhs(Nodes_v+iglob)=rhs(Nodes_v+iglob)+...
                        this.f_2(x,y)/3*Area_v(iel);
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            for iel=1:this.P.Nelem
                for iloc=1:3
                    iglob=triang_p(iel,iloc);
                    rhs(2*Nodes_v+iglob)=rhs(2*Nodes_v+iglob)+this.g(x,y)/3*Area_p(iel);
                    P_bc(iglob)=P_bc(iglob)+Area_p(iel)/3;
                end
            end
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% MATRIX CONSTRUCTION
        %%% MASS MATRIX
        function [M, A, HT1, HT2] = BuildMass_Diff(this)
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            H_val    = zeros(Nelem_v*9,1);
            M_val    = zeros(Nelem_v*9,1);
            HT1_val = zeros(Nelem_v*9,1);
            HT2_val = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=triang_v(iel,iloc);
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=triang_v(iel,jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        H_val(it)=(Bloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                   Cloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                               
                        HT1_val(it) = (Bloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                       Bloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                        HT2_val(it) = (Cloc_v(iel,iloc)*Bloc_v(iel,jloc)+...
                                       Cloc_v(iel,iloc)*Cloc_v(iel,jloc))*Area_v(iel);
                        %--------------------------------------------------
                        if iloc==jloc
                             M_val(it)=Area_v(iel)/6;
                         else
                             M_val(it)=Area_v(iel)/12;
                        end
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            % BUILD MATRICES
            A = sparse(i_sparse,j_sparse,H_val);
            M = sparse(i_sparse,j_sparse,M_val);
            HT1 = sparse(i_sparse,j_sparse,HT1_val);
            HT2 = sparse(i_sparse,j_sparse,HT2_val);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD BILINEAR FORM b(v,q)
        %------------------------------------------------------------------
        function [B1, B2] = Build_b(this)
            %--------------------------------------------------------------
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            B1_val   = zeros(36*this.P.Nelem,1);
            B2_val   = zeros(36*this.P.Nelem,1);
            % 
            i_p      = zeros(36*this.P.Nelem,1);
            k_p      = zeros(36*this.P.Nelem,1);
            % 
            %--------------------------------------------------------------
            % Build B1 and B2
            it = 1;
            for kel = 1 : this.P.Nelem
                triNB = this.connectivity(kel,:);
                for kloc = 1:3
                    kglob = this.P.triang(kel,kloc);
                    for iel_loc = 1 : 4
                        iel = triNB(iel_loc);
                        for iloc = 1 : 3
                            iglob = triang_v(iel,iloc);
                            B1 = 0;
                            B2 = 0;
                            %----------------------------------------------
                            if kloc == iel_loc
                                % first sum
                                B1=B1+Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+Cloc_v(iel,iloc)*Area_v(iel)/3;
                            end
                            %----------------------------------------------
                            if kloc == iel_loc || iel_loc == 4
                                % double second sum
                                B1=B1+0.5*2*Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+0.5*2*Cloc_v(iel,iloc)*Area_v(iel)/3;
                            else 
                                % just one second sum
                                B1=B1+0.5*Bloc_v(iel,iloc)*Area_v(iel)/3;
                                B2=B2+0.5*Cloc_v(iel,iloc)*Area_v(iel)/3;
                            end
                            %----------------------------------------------
                            % update
                            i_p(it)=iglob;
                            k_p(it)=kglob;
                            B1_val(it)=-B1;
                            B2_val(it)=-B2;
                            it=it+1;
                        end
                    end
                end
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            B1=sparse(k_p,i_p,B1_val);
            B2=sparse(k_p,i_p,B2_val);
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
        %% BUILD M_alpha
        %------------------------------------------------------------------
        function [M_alpha] = BuildMalpha(this)
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            Malpha_val    = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                verteces = triang_v(iel,:);
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=triang_v(iel,iloc);
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX 
                        %--------------------------------------------------
                        jglob=triang_v(iel,jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        %--------------------------------------------------
                        %%% int_\Omega { alpha(x) phi_i phy_j} with
                        %%% gaussian quadrature of order 2
                        % sum_i { alpha(b_i) phi_i(b_i) phi_j(b_i) }
                        if iloc==jloc
                             Malpha_val(it)= 1/4 * (2*this.alpha(iglob) + ...
                                               this.alpha(verteces(mod_n(iloc+1,3)))...
                                             + this.alpha(verteces(mod_n(iloc+2,3))))/2 * ...
                                               Area_v(iel) / 3;
                         else
                             Malpha_val(it) = 1/4 * (this.alpha(iglob) ... 
                                              + this.alpha(jglob))/2 *...
                                                Area_v(iel) / 3;
                        end
                        Malpha_val(it) = 1/4 * (this.alpha(iglob) + this.alpha(jglob))/2 * Area_v(iel) / 3;
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            % BUILD MATRICES
            M_alpha = sparse(i_sparse,j_sparse,Malpha_val);
            %--------------------------------------------------------------
        end
    end
end


function findEdgeId = findEdgeId(i, j , edges, edgesId)
    N = length(edges);
    for k= 1:N
        if (i == edges(k,1) && j == edges(k,2)) || (i == edges(k,2) && j == edges(k,1))
            findEdgeId =  edgesId(k);
            return
        end
    end
end

function findNodeId = findNodeId(node, edges, edgesId)
    N = length(edges);
    for i = 1:N
        if (node == edges(k,1) || node == edges(k,2))
            findNodeId = edgesId(i);
            return
        else
            write('Not a Boundary Node');
            findNodeId = -1;
            return
        end
    end
end
    

