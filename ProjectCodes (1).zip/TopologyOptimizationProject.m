%% TOPOLOGY OPTIMIZATION PROJECT
classdef TopologyOptimizationProject
    
    %------------------------------------------------------------------
    %% PROPERTIES
    %------------------------------------------------------------------
    properties

        onlyNS;
        %--------------------------------------------------------------------------
        % PROBLEM NAME
        %--------------------------------------------------------------------------
        problem;
        meshdir;
        nfig;

        %--------------------------------------------------------------------------
        % MODEL PARAMETERS
        %--------------------------------------------------------------------------
        flag;
        mu;
        rho;
        c;
        f_1;
        f_2;
        g;
        tau;
        nInletId;
        inlet_id;
        nOutletId;
        outlet_id;
        V_r;
        V_0;
        flag_BC;
        u_in;

        %--------------------------------------------------------------------------
        % TOPOLOGY OPTIMIZATION PARAMETERS
        %--------------------------------------------------------------------------
        flag_functional;
        alpha_min;
        alpha_max;
        q;

        %--------------------------------------------------------------------------
        % NS SOLVER, ADJOINT SOLVER, AND OPTIMIZATION PROCEDURE
        %-------------------------------------------------------------------------- 
        NavierStokes;
        AdjointSystem;
        MethodMovingAsymptotes;

        %--------------------------------------------------------------------------
        % TERMINATION METHOD
        %--------------------------------------------------------------------------
        terminationMethod;
        maxIt;
        toll;

        %--------------------------------------------------------------------------
        % SOLUTIONS
        %--------------------------------------------------------------------------
        u1;
        u2;
        p;
        gamma;
    end
    %------------------------------------------------------------------

    %------------------------------------------------------------------
    %% METHODS
    %------------------------------------------------------------------
    methods
        %------------------------------------------------------------------
        % CONSTRUCTOR
        %------------------------------------------------------------------
        function this = TopologyOptimizationProject(OnlyNS)
            [this.problem, this.meshdir, this.NavierStokes, this.nfig, this.rho, this.mu, this.f_1, this.f_2, this.g, ...
             this.nInletId, this.inlet_id, this.nOutletId, this.outlet_id, this.flag, ...
             this.flag_BC, this.V_r, this.V_0,this.c, this.tau, this.flag_functional, this.alpha_min, this.alpha_max, this.q, this.terminationMethod, this.maxIt, this.toll, this.u_in] = Solver.NStokesParameters();
           
            this.onlyNS = OnlyNS;
        end
        %------------------------------------------------------------------
        % LAUNCH TOPOLOGY OPTIMIZATION PROBLEM
        %------------------------------------------------------------------
        function this = launchProblem(this)
            limits = [this.NavierStokes.X_limits, this.NavierStokes.Y_limits];
            this.nfig = this.nfig+1;

            %--------------------------------------------------------------------------
            % INITIALIZE PARAMETER GAMMA
            %--------------------------------------------------------------------------
            itCount = 1;
            this.gamma(:,itCount) = 1.0 *ones(this.NavierStokes.V.Nodes,1);
  
            
            %--------------------------------------------------------------------------
            % set BC
            %--------------------------------------------------------------------------
            tic;
            disp('-----------------------------------')
            disp('SET BC');
            disp('-----------------------------------'); disp('-----------------------------------');

            % Edge Index imported from COMSOL       

           % SET DIRICHLET BC
            for inletId = 1:length(this.inlet_id)
                this.NavierStokes = this.NavierStokes.setEdgeDirBC(this.inlet_id(inletId), this.u_in);
            end

            % SET NO SLIP BC
            for i = 1 : max(this.NavierStokes.Bound.EdgesId)
                if ismember(i, this.inlet_id) || ismember(i, this.outlet_id)
                    continue
                else
                    this.NavierStokes = this.NavierStokes.setEdgeDirBC(i, @(x,y) [0,0]);
                end
            end

            
             % SET OPEN BOUNDARY BC
            for outletId = 1:length(this.outlet_id)
                this.NavierStokes = this.NavierStokes.setEdgeNeuBC(this.outlet_id(outletId), [0,0]);
            end
            toc;
            %--------------------------------------------------------------------------
            % PREPRO
            %--------------------------------------------------------------------------
            tic;
            disp('-----------------------------------')
            disp('PREPRO');
            disp('-----------------------------------'); disp('-----------------------------------');
            this.NavierStokes = this.NavierStokes.prepro;
            toc;
            %%% !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            %--------------------------------------------------------------------------
            % INITIALIZE ADJOINT AND MMA SOLVER
            %--------------------------------------------------------------------------
            tic;
            disp('-----------------------------------')
            disp('ADJOINT SYSTEM AND MMA INITIALIZATION');
            disp('-----------------------------------'); disp('-----------------------------------');
            % initialize Adjoint
            this.AdjointSystem = ADJOINT_NS(this.NavierStokes, this.mu, this.rho, this.flag_functional);
            % initialize MMA
            this.MethodMovingAsymptotes = MMA(this.q, this.V_r, this.V_0, this.alpha_min, this.alpha_max, this.NavierStokes.V, this.mu, this.flag_functional);
            toc;
            %--------------------------------------------------------------------------
            loop = 0;
            this.toll = 1e-3;
            change = this.toll + 1;
            [u1_0, u2_0] = this.NavierStokes.zeroInitCond();
            it = 0;
            %%  LAUNCH SOLVER
            while (change > this.toll)
                it = it+1;
                %--------------------------------------------------------------------------
                % UPDATE PARAMETER GAMMA
                %--------------------------------------------------------------------------
                alpha = this.alpha_min + (this.alpha_max - this.alpha_min).*this.q.*(1-this.gamma(:,itCount))./(this.q+this.gamma(:,itCount));
                this.NavierStokes.alpha = alpha;
                %--------------------------------------------------------------------------
                % SOLVE
                %--------------------------------------------------------------------------
                tic;
                disp('-----------------------------------')
                disp('SOLVE MASTER PROBLEM');
                disp('-----------------------------------');disp('-----------------------------------');
                [uh1, uh2, ph] = this.NavierStokes.StatSolver(this.flag_BC, u1_0, u2_0);
                toc;
                this.u1(:,itCount) = uh1;
                this.u2(:,itCount) = uh2;
                this.p(:,itCount)  = ph;

                %this.NavierStokes.PrintRes(uh1,uh2,ph,2, limits);

                % figure(nfig)
                % nfig = nfig + 1;
                % axis ([0 5, 0 1]);
                % axis equal;
                % x = this.NavierStokes.V.coord(:,1);
                % y = this.NavierStokes.V.coord(:,2);
                % quiver(x,y,uh1,uh2);

                figure(5)

                for iedge = 1:size(this.NavierStokes.Bound.Edges,1)
                    p1 = this.NavierStokes.V.coord(this.NavierStokes.Bound.Edges(iedge,1),:);
                    p2 = this.NavierStokes.V.coord(this.NavierStokes.Bound.Edges(iedge,2),:);
                    plot([p1(1), p2(1)], [p1(2), p2(2)], 'k-');
                    hold on;
                end

                [x,y] = meshgrid(this.NavierStokes.X_limits(1):0.1:this.NavierStokes.X_limits(2), ...
                    this.NavierStokes.Y_limits(1):0.1:this.NavierStokes.Y_limits(2));
                u = zeros(size(x)); v = zeros(size(x));                
                for i = 1:numel(x)
                    [u(i), v(i)]= this.NavierStokes.getApproxValue_v([x(i);y(i)],uh1,uh2);
                    if norm([u(i), v(i)]) < 1e-2
                        u(i) = 0;
                        v(i) = 0;
                    end
                end
                quiver(x,y,u,v, 'Color', 'b');
                %streamslice(x,y,u,v);
                startY = 0:0.05:1;
                startX = zeros(length(startY),1);
                streamline(x,y,u,v,startX',startY);
                axis (limits)
                axis equal
                hold off;
                if not(this.onlyNS)
                    %--------------------------------------------------------------------------
                    % BUILD ADJOINT SYSTEM
                    %--------------------------------------------------------------------------
                    tic;
                    disp('-----------------------------------')
                    disp('Build Adjoint system');
                    disp('-----------------------------------');
                    this.AdjointSystem = this.AdjointSystem.Update(uh1,uh2,ph,alpha);

                    switch this.flag_functional
                        case 1
                            this.AdjointSystem.f_1    = -2*alpha.*uh1/this.rho;
                            this.AdjointSystem.f_2    = -2*alpha.*uh2/this.rho;
                            this.AdjointSystem.g      = zeros(this.AdjointSystem.P.Nodes);
                        case 2
                            this.AdjointSystem.f_1    = -2*alpha.*uh1/this.rho;
                            this.AdjointSystem.f_2    = -2*alpha.*uh2/this.rho;
                            this.AdjointSystem.g      = zeros(this.AdjointSystem.P.Nodes);
                        case 3
                            this.AdjointSystem.f_1    = zeros(this.AdjointSystem.V.Nodes);
                            this.AdjointSystem.f_2    = zeros(this.AdjointSystem.V.Nodes);
                            this.AdjointSystem.g      = zeros(this.AdjointSystem.P.Nodes);
                        case 4
                            this.AdjointSystem.f_1    = zeros(this.AdjointSystem.V.Nodes);
                            this.AdjointSystem.f_2    = zeros(this.AdjointSystem.V.Nodes);
                            this.AdjointSystem.g      = zeros(this.AdjointSystem.P.Nodes);
                    end

                    this.AdjointSystem = this.AdjointSystem.clearBC();
                    toc;

                    %--------------------------------------------------------------------------
                    % set BC
                    %--------------------------------------------------------------------------
                    tic;
                    disp('-----------------------------------')
                    disp('SET ADJOINT BC');
                    disp('-----------------------------------'); disp('-----------------------------------');

                    for i = 1:this.NavierStokes.Bound.NBound
%                         if ismember(i,this.outlet_id)
%                             continue
%                         end
                        this.AdjointSystem = this.AdjointSystem.setEdgeDirBC(i,@(x,y)[0,0]);
                    end
                    this.AdjointSystem = this.AdjointSystem.setEdgeNeuBC(this.outlet_id);

                    toc;
                    %--------------------------------------------------------------------------
                    % SOLVE
                    %--------------------------------------------------------------------------
                    tic;
                    disp('-----------------------------------')
                    disp('ADJOINT SOLVER');
                    disp('-----------------------------------'); disp('-----------------------------------')
                    this.AdjointSystem = this.AdjointSystem.Prepro;
                    [ua1, ua2, ~] = this.AdjointSystem.DirectStatSolver(this.flag_BC);
                    toc;

                    %--------------------------------------------------------------------------
                    % CALL MMA METHOD
                    %--------------------------------------------------------------------------
                    tic;
                    disp('-----------------------------------')
                    disp('UPDATE AND SOLVE MMA');
                    disp('-----------------------------------'); disp('-----------------------------------')
                    this.MethodMovingAsymptotes = this.MethodMovingAsymptotes.Update(uh1, uh2, ua1, ua2);
                    [gamma_new, f0val, Vol] = this.MethodMovingAsymptotes.solve(this.gamma(:,itCount));
                    toc;

                    % PRINT RESULTS
                    change = Solver.evalErr(this.gamma(:,itCount), gamma_new, this.NavierStokes.V);
                    %                 change = max(max(abs(gamma_new-this.gamma(:,itCount))));
                    loop  = loop + 1;
                    disp([' It.: ' sprintf('%4i',loop) ' Obj.: ' sprintf('%10.4f',f0val) ...
                        ' Vol.: ' sprintf('%6.3f',Vol) ...
                        ' ch.: ' sprintf('%6.3f',change )]);

                    % % PLOT DENSITIES
                    figure(6)

                    x=this.NavierStokes.V.coord(:,1); y=this.NavierStokes.V.coord(:,2);
                    M=delaunay(x,y);
                    cd triplot
                    tricontf(x,y,M,gamma_new,10);
                    colormap(gray);
                    itCount = itCount + 1;
                    this.gamma(:,itCount) = gamma_new;
                    axis(limits);
                    axis equal
                    colorbar
                    cd ..
                end
                if this.terminationMethod == "iteration"
                    if it == this.maxIt
                        change = this.toll-1;
                    end
                end
            end
        end

        %------------------------------------------------------------------
        % CREATE MESH NODES FILE 
        %------------------------------------------------------------------
        function createMeshNodes(this)
            problemName = this.problem;
            x = this.NavierStokes.P.coord(:,1);
            y = this.NavierStokes.P.coord(:,2);

            fNodesID = strcat('mesh_COMSOL\', problemName, '\', problemName, '_mesh_nodes.txt');
            fileNodesID = fopen(fNodesID, 'w');
            format('long');
            for i=1:this.NavierStokes.P.Nodes
                fprintf(fileNodesID, '%f %f \n' , x(i), y(i));
            end
            fclose(fileNodesID);
        end

        %------------------------------------------------------------------
        % CREATE SOLUTIONS FILE (to compare with COMSOL) 
        %------------------------------------------------------------------
        function createSolutions(this)
            problemName = this.problem;

            [uh1, uh2, ph, gammah] = TopologyOptimizationProject.loadSolution(strcat('mesh_COMSOL\', problemName, '\'));

            x = this.NavierStokes.P.coord(:,1);
            y = this.NavierStokes.P.coord(:,2);

            fSolID = strcat('mesh_COMSOL\', problemName, '\', problemName, '_mat_sol.txt');
            fileSolID = fopen(fSolID, 'w');
            format('long');
            for i=1:this.NavierStokes.P.Nodes
                fprintf(fileSolID, '%f %f %f %f %f \n' , x(i), y(i), uh1(i,1), uh2(i,1), ph(i,1));
            end
            fclose(fileSolID);
        end
    end
    %------------------------------------------------------------------
    %% STATIC METHODS
    %------------------------------------------------------------------ 
    methods (Static)
        %------------------------------------------------------------------
        % CREATE RESULTS HISTORY 
        %------------------------------------------------------------------
        function saveVariablesResults(pb, u1, u2, p, gamma)
            fileu1ID    = strcat('mesh_COMSOL\', pb, '\u1_sol', '.txt');
            fileu2ID    = strcat('mesh_COMSOL\', pb, '\u2_sol', '.txt');
            filepID     = strcat('mesh_COMSOL\', pb, '\p_sol', '.txt');
            filegammaID = strcat('mesh_COMSOL\', pb, '\gamma_sol', '.txt');
%             fileu1 = fopen(fileu1ID, 'w');
%             fileu2 = fopen(fileu2ID, 'w');
%             filep = fopen(filepID, 'w');
%             filegamma = fopen(filegammaID, 'w');
            writematrix(u1, fileu1ID);
            writematrix(u2, fileu2ID);
            writematrix(p, filepID);
            writematrix(gamma, filegammaID);
        end

        %------------------------------------------------------------------
        % LOAD LAST SOLUTION FOR THE CURRENT PROJECT
        %------------------------------------------------------------------
        function [u1, u2, p, gamma] = loadSolution(solFolder)
            u1 = readmatrix([solFolder, 'u1_sol.txt']);
            u2 = readmatrix([solFolder, 'u2_sol.txt']);
            p = readmatrix([solFolder, 'p_sol.txt']);
            gamma = readmatrix([solFolder, 'gamma_sol.txt']);
        end

        %------------------------------------------------------------------
        % COMPARE SOLUTIONS WITH RELATIVE ERROR
        %------------------------------------------------------------------
        function [eu1, eu1r, eu2, eu2r, ep, epr] = compareSolutions(project, sol1, sol2) %sol1, sol2 are .txt files directories
                                                               % with u1,u2,p values
            [xM, yM, u1_sol1, u2_sol1, p_sol1] = readvars(sol1);
            [xC, yC, u1_sol2, u2_sol2, p_sol2] = readvars(sol2);
            
            eu1 = Solver.evalErr(u1_sol1, u1_sol2, project.NavierStokes.P);
            eu1r = eu1/(Solver.evalErr(u1_sol2, zeros(length(u1_sol1)), project.NavierStokes.P));
            
            eu2 = Solver.evalErr(u2_sol1, u2_sol2, project.NavierStokes.P);
            eu2r = eu2/(Solver.evalErr(u2_sol2, zeros(length(u2_sol1)), project.NavierStokes.P));
            
            ep  = Solver.evalErr(p_sol1, p_sol2, project.NavierStokes.P);
            epr = ep/(Solver.evalErr(p_sol2, zeros(length(p_sol1)), project.NavierStokes.P));

            fErrID = strcat('mesh_COMSOL\', project.problem, '\error_mat_com', '.txt');
            fileErrID = fopen(fErrID,'w');
            format long;
            fprintf(fileErrID,['ABSOLUTE ERRORS for the "%s" problem: \n' ...
                        'eu1 = %5.3e \n' ...
                        'eu2 = %5.3e \n' ...
                        'ep  = %5.3e \n'], project.problem, eu1, eu2, ep);
            fprintf(fileErrID,['\nRELATIVE ERRORS for the "%s" problem: \n' ...
                        'eu1r = %5.3e \n' ...
                        'eu2r = %5.3e \n' ...
                        'epr  = %5.3e \n'], project.problem, eu1r, eu2r, epr);
        end
    end
    %------------------------------------------------------------------

end