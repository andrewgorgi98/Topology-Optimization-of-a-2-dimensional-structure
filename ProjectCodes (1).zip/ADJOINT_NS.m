classdef ADJOINT_NS < ADJOINT
    %ADJOINT_NS Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        ni;
        h;
        tau;
    end
    
    methods (Access = public)
        %------------------------------------------------------------------
        %% CONSTRUCTOR
        %------------------------------------------------------------------
        function this = ADJOINT_NS(solver, mu, rho, func_id)
            this@ADJOINT(solver,mu, rho, func_id);
            this.ni  = solver.ni;
            this.tau = solver.tau;
            this.h   = solver.h;
        end
        %------------------------------------------------------------------
        %% BUILD THE STIFFNESS MATRIX
        
        function SYSMAT = stiffBuild(this, c)
            %--------------------------------------------------------------
            Nodes_v = this.V.Nodes;
            Nodes_p  = this.P.Nodes;
            %----
            A  = this.ni * this.LinSys.A;
            M  = c * this.LinSys.M;
            [N, L1, L2] = BuildN_L1_L2(this);
%             N = this.rho*N; L1 = this.rho*L1; L2 = this.rho*L2;
            M_alpha     = BuildMalpha(this)/this.rho;
            B1 = this.LinSys.B1/this.rho;
            B2 = this.LinSys.B2/this.rho;
            %----
            SYSMAT=[A+M-N+L1+M_alpha       , sparse(Nodes_v,Nodes_v), B1';
                    sparse(Nodes_v,Nodes_v), A+M-N+L2+M_alpha       , B2';
                    B1                     , B2                     , sparse(Nodes_p,Nodes_p)];
            %--------------------------------------------------------------
        end
        %------------------------------------------------------------------
    end
    %----------------------------------------------------------------------
    %%% PROTECTED METHODS!!
    %----------------------------------------------------------------------
    methods (Access = protected)
        function [N, L1, L2] = BuildN_L1_L2(this)
            % N1 =  - (u * grad) u_a;
            % N2 = (grad u) * u_a;
            %--------------------------------------------------------------
            Nelem_v  = this.V.Nelem;
            triang_v = this.V.triang;
            Bloc_v   = this.V.Bloc;
            Cloc_v   = this.V.Cloc;
            Area_v   = this.V.Area;
            %--------------------------------------------------------------
            % initialize vectors for sparse allocation
            i_sparse = zeros(Nelem_v*9,1);
            j_sparse = zeros(Nelem_v*9,1);
            N_val    = zeros(Nelem_v*9,1);
            L1_val   = zeros(Nelem_v*9,1);
            L2_val   = zeros(Nelem_v*9,1);
            % 
            it=1;
            %--------------------------------------------------------------
            for iel=1:Nelem_v
                %----------------------------------------------------------
                % ENTER THE ELEMENT
                %----------------------------------------------------------
                verteces = triang_v(iel,:);
                beta1 = this.uh1(verteces,1); beta2 = this.uh2(verteces,1);
                for iloc=1:3
                    %------------------------------------------------------
                    % SELECT FIRST VERTEX
                    %------------------------------------------------------
                    iglob=verteces(iloc);
                    beta1_mean =[2*beta1(iloc)            + beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3));
                                 2*beta2(iloc)            + beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3))];
                    beta2_mean =[2*beta1(mod_n(iloc+1,3)) + beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3));
                                 2*beta2(mod_n(iloc+1,3)) + beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3))];
                    beta3_mean =[2*beta1(mod_n(iloc+2,3)) + beta1(mod_n(iloc+3,3)) + beta1(mod_n(iloc+4,3));
                                 2*beta2(mod_n(iloc+2,3)) + beta2(mod_n(iloc+3,3)) + beta2(mod_n(iloc+4,3))];
                    for jloc=1:3
                        %--------------------------------------------------
                        % SELECT SECOND VERTEX AND COMPUTE MATRICES ENTRY
                        %--------------------------------------------------
                        jglob=verteces(jloc);
                        i_sparse(it)=iglob;
                        j_sparse(it)=jglob;
                        %--------------------------------------------------
                        %%% BUILD N CONVECTIVE MATRIX
                        %--------------------------------------------------
                        N_valval = 1/4*(beta1_mean' * [Bloc_v(iel,jloc); Cloc_v(iel,jloc)]) ...
                                          * Area_v(iel)/3;

                        if norm(beta1_mean) > 1e-3
                        S = this.tau/this.mu*this.h(iel)/2 / norm(beta1_mean) *...
                                [Bloc_v(iel,jloc), Cloc_v(iel,jloc)] * [beta1_mean, beta2_mean, beta3_mean] * ...
                                [beta1_mean'; beta2_mean'; beta3_mean'] * [Bloc_v(iel,iloc); Cloc_v(iel,iloc)] * ...
                                 Area_v(iel)/3;
                        else
                            S = 0;
                        end
                        N_val(it) = N_valval + S;
                        %--------------------------------------------------
                        %%% BUILD L MATRIX, (grad u * u_a) * v
                        %--------------------------------------------------
                        if iloc==jloc
                             M = Area_v(iel)/6;
                         else
                             M = Area_v(iel)/12;
                        end
                        temp_L1 = 0;
                        temp_L2 = 0;
                        for kloc = 1:3
                            temp_L1 = temp_L1 + beta1(kloc) * Bloc_v(iel,kloc) * M;
                            temp_L2 = temp_L2 + beta2(kloc) * Cloc_v(iel,kloc) * M;
                        end
                        L1_val(it) = temp_L1;
                        L2_val(it) = temp_L2;
                        %--------------------------------------------------
                         it=it+1;
                        %--------------------------------------------------
                    end
                    %------------------------------------------------------
                end
                %----------------------------------------------------------
            end
            %--------------------------------------------------------------
            % BUILD MATRICES
            N  = sparse(i_sparse,j_sparse,N_val);
            L1 = sparse(i_sparse,j_sparse,L1_val);
            L2 = sparse(i_sparse,j_sparse,L2_val);
            %--------------------------------------------------------------
        end
    end 
end